package ui;

import model.Queue;

public class Main {
    public static void main(String[] args) {
        Queue<Integer> pruebaQueue = new Queue<>();
        pruebaQueue.enqueue(1);
        pruebaQueue.enqueue(2);
        pruebaQueue.enqueue(3);
        pruebaQueue.enqueue(4);
        pruebaQueue.enqueue(5);

        System.out.println("tirando elementos: ");
        //System.out.println(pruebaQueue.dequeue());
        System.out.println(pruebaQueue.dequeue());
        System.out.println(pruebaQueue.dequeue());
        System.out.println(pruebaQueue.dequeue());
        System.out.println(pruebaQueue.dequeue());
        System.out.println(pruebaQueue.dequeue());

    }
}
