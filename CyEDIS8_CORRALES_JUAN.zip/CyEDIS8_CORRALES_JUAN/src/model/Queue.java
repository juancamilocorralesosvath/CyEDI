package model;

import java.util.NoSuchElementException;

// implementación de una cola haciendo uso de dos pilas.
public class Queue<T> implements IQueue<T> {
    private Stack2<T> firstStack;
    private Stack2<T> lastSatck;
    private int size;

    public Queue() {
        firstStack = new Stack2<>();
        lastSatck = new Stack2<>();
        size = 0;
    }

    @Override
    public void enqueue(T element) {
        if(firstStack.isEmpty()) firstStack.push(element);
        else lastSatck.push(element);
    }

    @Override
    public T dequeue() {
        if (isEmpty()) throw new NoSuchElementException("Queue underflow");
        T element = firstStack.pop();
        if(!lastSatck.isEmpty()){
            firstStack.push(lastSatck.getBottom());
        }
        return element;
    }

    @Override
    public T front() {
        return firstStack.peek();
    }

    @Override
    public boolean isEmpty() {
        return firstStack.isEmpty();
    }
}
