package model;

public interface IStack2<T> {
    boolean isEmpty();
    int size();
    void push(T item);
    T pop();
    T peek();
}
