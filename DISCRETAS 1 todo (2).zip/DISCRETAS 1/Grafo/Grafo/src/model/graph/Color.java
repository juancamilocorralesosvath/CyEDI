package model.graph;

public enum Color {
    WHITE, GRAY
}
