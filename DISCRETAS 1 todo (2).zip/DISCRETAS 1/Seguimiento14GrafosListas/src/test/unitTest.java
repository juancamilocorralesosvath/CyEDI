package test;

import model.Color;
import model.GrafoLista;
import model.Node;
import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.*;

public class unitTest {


        @Test
        public void testAgregarVertice() {
            GrafoLista<Integer> grafo = new GrafoLista<>();
            Node<Integer> nodo1 = new Node<>("1", null, 0, Color.BLANCO);
            Node<Integer> nodo2 = new Node<>("2", null, 0, Color.BLANCO);
            grafo.añadirVertice(nodo1);
            grafo.añadirVertice(nodo2);
            assertTrue(grafo.listaVertices.contains(nodo1));
            assertTrue(grafo.listaVertices.contains(nodo2));
        }

    @Test
    public void testDFS() {
        GrafoLista<String> grafo = new GrafoLista<>();
        Node<String> v1 = new Node<>("1", null, 0, Color.BLANCO);
        Node<String> v2 = new Node<>("2", null, 0, Color.BLANCO);
        Node<String> v3 = new Node<>("3", null, 0, Color.BLANCO);
        Node<String> v4 = new Node<>("4", null, 0, Color.BLANCO);
        Node<String> v5 = new Node<>("5", null, 0, Color.BLANCO);
        Node<String> v6 = new Node<>("6", null, 0, Color.BLANCO);

        grafo.añadirVertice(v1);
        grafo.añadirVertice(v2);
        grafo.añadirVertice(v3);
        grafo.añadirVertice(v4);
        grafo.añadirVertice(v5);
        grafo.añadirVertice(v6);

        v1.añadirAdyacentes(v2);
        v1.añadirAdyacentes(v3);
        v2.añadirAdyacentes(v4);
        v3.añadirAdyacentes(v4);
        v4.añadirAdyacentes(v5);
        v5.añadirAdyacentes(v6);

        grafo.dfs(0);

        assertEquals(1, v1.getDescubierto());
        assertEquals(12, v6.getFinalizado());
    }

    @Test
    public void testBFS() {
        GrafoLista<String> grafo = new GrafoLista<>();
        Node<String> v1 = new Node<>("1", null, 0, Color.BLANCO);
        Node<String> v2 = new Node<>("2", null, 0, Color.BLANCO);
        Node<String> v3 = new Node<>("3", null, 0, Color.BLANCO);
        Node<String> v4 = new Node<>("4", null, 0, Color.BLANCO);
        Node<String> v5 = new Node<>("5", null, 0, Color.BLANCO);
        Node<String> v6 = new Node<>("6", null, 0, Color.BLANCO);

        grafo.añadirVertice(v1);
        grafo.añadirVertice(v2);
        grafo.añadirVertice(v3);
        grafo.añadirVertice(v4);
        grafo.añadirVertice(v5);
        grafo.añadirVertice(v6);

        v1.añadirAdyacentes(v2);
        v1.añadirAdyacentes(v3);
        v2.añadirAdyacentes(v4);
        v3.añadirAdyacentes(v4);
        v4.añadirAdyacentes(v5);
        v5.añadirAdyacentes(v6);

        grafo.bfs(0);

        assertEquals(0, v1.getDistancia());
        assertEquals(1, v2.getDistancia());
        assertEquals(1, v3.getDistancia());
        assertEquals(2, v4.getDistancia());
        assertEquals(3, v5.getDistancia());
        assertEquals(4, v6.getDistancia());
    }

}