package model;

import java.util.ArrayList;

public class Arista <T>{

    private int peso;
    private Node<T> vertice1;
    private Node<T> vertice2;

    public Arista(int peso, Node<T> vertice1, Node<T> vertice2){

        this.peso = peso;
        this.vertice1 = vertice1;
        this.vertice2 = vertice2;

    }



}