package model;

import java.util.ArrayList;

public class Controladora {

    boolean flagDouble = false;

    private GrafoLista<String> grafo;

    public Controladora(){

        grafo = new GrafoLista<String>();

    }

    public void añadirAdyacentes(int vertice, int padre) {

        boolean flag = true;

        int cuenta = 0;

        if(grafo.listaVertices.get(padre).getAdyacentes().isEmpty() != true) {

            for(int l = 0; l < grafo.listaVertices.get(padre).getAdyacentes().size();l++) {
			/*
			System.out.println("Prueba");

			System.out.println(grafo.listaVertices.get(padre).getAdyacentes().size()+1);
			*/
                //System.out.println(grafo.listaVertices.get(padre).getAdyacentes().get(vertice));
                //System.out.println(grafo.listaVertices.get(padre).getAdyacentes().get(vertice+1));

                if(grafo.listaVertices.get(padre).getAdyacentes().get(l).getId() != grafo.listaVertices.get(vertice).getId()/* || grafo.listaVertices.get(padre).getAdyacentes().get(l) != grafo.listaVertices.get(padre)*/) {
                    System.out.println("Prueba");
                }else {
                    cuenta++;
                }

            }

        }

        if(cuenta >= 1) {

            flag= false;

        }

        if(flag == true) {

            grafo.listaVertices.get(vertice).setPadre(grafo.listaVertices.get(padre));
            grafo.listaVertices.get(padre).añadirAdyacentes(grafo.listaVertices.get(vertice));

        } else {

            System.out.println("El vertice ya está en la lista de adyacencia.");

        }
    }

    public void añadirVertice(String id) {

        grafo.añadirVertice(new Node(id, null, 0, Color.BLANCO));

    }

    public void imprimir(){

        System.out.println("\nLista de vertices actuales: \n");

        for(int i = 0; i < grafo.listaVertices.size(); i++) {

            System.out.println((i+1)+ ". " + grafo.listaVertices.get(i).getId());

        }

    }

    public void imprimirAdyacentes(int k){

        System.out.println("\nLista de adyacencia del vertice " + grafo.listaVertices.get(k).getId() + ":\n");

        String x = "";

        for(int s = 0; s < grafo.listaVertices.get(k).getAdyacentes().size(); s++) {

            if(grafo.listaVertices.get(k).getAdyacentes().get(s) != null) {


                x = grafo.listaVertices.get(k).getId() + " [";

            } else if(grafo.listaVertices.get(k).getAdyacentes().get(s) == null){

                //System.out.println("Prueba");

                x = grafo.listaVertices.get(k).getId();

            }

        }
        for(int i = 0; i < grafo.listaVertices.get(k).getAdyacentes().size(); i++) {

            if (i != (grafo.listaVertices.get(k).getAdyacentes().size()-1)) {

                x += grafo.listaVertices.get(k).getAdyacentes().get(i).getId() + "-";

            }

            if(i==(grafo.listaVertices.get(k).getAdyacentes().size()-1)) {

                x += grafo.listaVertices.get(k).getAdyacentes().get(i).getId() + "]" ;

            }


        }

        System.out.println(x);

    }

    public String imprimirConcreto(int j) {

        return grafo.listaVertices.get(j).getId();

    }

    public boolean comprobarConectividad() {

        boolean flag = true;

        //System.out.println(grafo.listaVertices.size());

        for(int i = 0; i < grafo.listaVertices.size();i++) {

            grafo.bfs(i);

            for(int g = 0; g < grafo.listaVertices.size();g++) {

                //System.out.println(grafo.listaVertices.get(g).getColor());

                if(grafo.listaVertices.get(g).getColor() == Color.BLANCO) {

                    //System.out.println(grafo.listaVertices.get(j).getColor());
                    flag = false;

                }

            }

        }

        if(flag == false) {

            for(int f = 0; f < grafo.listaVertices.size(); f++) {

                imprimirAdyacentes(f);

            }

            System.out.println("El grafo actual no es fuertemente conexo.");

        }else {

            for(int f = 0; f < grafo.listaVertices.size(); f++) {

                imprimirAdyacentes(f);

            }

            System.out.println("El grafo actual es fuertemente conexo.");

        }

        return flag;

    }

}