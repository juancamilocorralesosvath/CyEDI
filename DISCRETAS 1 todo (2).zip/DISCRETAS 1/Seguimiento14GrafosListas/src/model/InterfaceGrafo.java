package model;

public interface InterfaceGrafo<T> {
    public Node<T> getVertice();
    public void setVertice(Node <T> vertice);
    public void añadirVertice(Node<T> vertice);
    public void bfs(int verticeInicial);
    public void dfs(int verticeInicial);
}
