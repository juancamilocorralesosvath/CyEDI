package model;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class GrafoLista<T>implements InterfaceGrafo {

    private Node<T> vertice;
    public ArrayList<Node<T>> listaVertices;
    private Queue<Node<T>> queue;
    ArrayList<Arista<T>> listaAristas;

    public GrafoLista(){

        this.vertice = vertice;
        listaVertices = new ArrayList<Node<T>>() ;
        queue = new LinkedList<Node<T>>();
        listaAristas = new ArrayList<Arista<T>>() ;


    }

    @Override
    public Node getVertice() {
        return vertice;
    }

    @Override
    public void setVertice(Node vertice) {
        this.vertice = vertice;

    }

    @Override
    public void añadirVertice(Node vertice) {
        listaVertices.add(vertice);

    }

    @Override
    public void bfs(int verticeInicial) {

        int tiempo = 0; // tiempo actual

        for (int i = 0; i < listaVertices.size(); i++) {
            listaVertices.get(i).setColor(Color.BLANCO);
            listaVertices.get(i).setPadre(null);
        }

        Stack<Node<T>> pila = new Stack<Node<T>>();
        Node<T> nodoInicial = listaVertices.get(verticeInicial);
        pila.push(nodoInicial);

        while (!pila.isEmpty()) {

            Node<T> nodoActual = pila.peek();

            if (nodoActual.getColor() == Color.BLANCO) {

                tiempo++;
                nodoActual.setDescubierto(tiempo);
                nodoActual.setColor(Color.GRIS);

                for (int i = 0; i < nodoActual.getAdyacentes().size(); i++) {
                    Node<T> nodoAdyacente = nodoActual.getAdyacentes().get(i);
                    if (nodoAdyacente.getColor() == Color.BLANCO) {
                        nodoAdyacente.setPadre(nodoActual);
                        pila.push(nodoAdyacente);
                    }
                }

            } else if (nodoActual.getColor() == Color.GRIS) {

            } else if (nodoActual.getColor() == Color.NEGRO) {

                tiempo++;
                nodoActual.setFinalizado(tiempo);
                pila.pop();

            }

        }

    }

    @Override
    public void dfs(int verticeInicial) {
        int tiempo = 0;
        for (int i = 0; i < listaVertices.size(); i++) {
            listaVertices.get(i).setColor(Color.BLANCO);
            listaVertices.get(i).setPadre(null);
        }
        Node<T> inicio = listaVertices.get(verticeInicial);
        inicio.setDescubierto(tiempo);
        dfsVisit(inicio, tiempo);
    }

    private void dfsVisit(Node<T> nodo, int tiempo) {
        tiempo++;
        nodo.setColor(Color.GRIS);
        nodo.setDescubierto(tiempo);
        for(int i = 0; i < nodo.getAdyacentes().size(); i++) {
            Node<T> vecino = nodo.getAdyacentes().get(i);
            if(vecino.getColor() == Color.BLANCO) {
                vecino.setPadre(nodo);
                dfsVisit(vecino, tiempo);
            }
        }
        nodo.setColor(Color.NEGRO);
        tiempo++;
        nodo.setFinalizado(tiempo);
    }
}
