package model;

import java.util.ArrayList;

public class Node <T>{

    private String id;
    private Node<T> padre;
    private int distancia;
    private Color color;
    private ArrayList<Node<T>> adyacentes;

    private int descubierto;
    private int finalizado;

    public Node(String id, Node<T> padre, int distancia, Color color){

        this.id = id;
        this.padre = padre;
        this.distancia = distancia;
        this.color = color;
        adyacentes = new ArrayList<Node<T>>();

    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public Node<T> getPadre() {
        return padre;
    }
    public void setPadre(Node<T> padre) {
        this.padre = padre;
    }

    public int getDistancia() {
        return distancia;
    }

    public void setDistancia(int distancia) {
        this.distancia = distancia;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public ArrayList<Node<T>> getAdyacentes() {
        return adyacentes;
    }

    public void setAdyacentes(ArrayList<Node<T>> adyacentes) {
        this.adyacentes = adyacentes;
    }

    public void añadirAdyacentes(Node<T> hijo) {
        adyacentes.add(hijo);
    }
    public void setDescubierto(int tiempo) {
        this.descubierto = tiempo;
    }
    public void setFinalizado(int tiempo) {
        this.finalizado = tiempo;
    }


    public int getDescubierto() {
        return this.descubierto;
    }

    public int getFinalizado() {
        return this.finalizado;
    }
}