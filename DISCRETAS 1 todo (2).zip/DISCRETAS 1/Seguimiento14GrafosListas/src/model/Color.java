package model;

public enum Color {
    BLANCO, GRIS, NEGRO
}
