import model.Controladora;

import java.io.IOException;
import java.util.Scanner;

public class Main<T> {

    public static Scanner sc;
    public static Controladora controladora;

    public Main(){

        sc = new Scanner(System.in);
        controladora = new Controladora();

    }

    public static void main(String [] args) throws IOException {




        Main obj = new Main();

        int option;

        obj.ShowMainMenu();



    }

    public void ShowMainMenu() throws IOException {

        System.out.println("Bienvenido.");

        boolean stopFlag = false;

        while (!stopFlag) {

            System.out.println("\n¿Que desea hacer?");
            System.out.println("1. Agregar vertices.");
            System.out.println("2. Agregar adyacentes.");
            System.out.println("3. Validar si el grafo es fuertemente conexo.");
            System.out.println("4. Salir.");

            int mainOption = sc.nextInt();

            switch (mainOption) {

                case 1:

                    boolean flag = false;

                    while(flag == false) {

                        System.out.println("\nDesea agregar un vertice?");

                        System.out.println("1. Si.");
                        System.out.println("2. No.");

                        int opcion = sc.nextInt();

                        switch(opcion) {

                            case 1:


                                System.out.println("\nIngrese el id del vertice: ");

                                String id = sc.next();

                                controladora.añadirVertice(id);


                                break;
                            case 2:

                                flag = true;

                                break;
                        }

                    }

                    controladora.imprimir();

                    break;
                case 2:

                    boolean flag2 = false;

                    while(flag2 == false) {

                        System.out.println("\nSeleccione a cual vertice desea añadir adyacentes:");

                        controladora.imprimir();

                        int padre = sc.nextInt();

                        System.out.println("\nSeleccione cual vertice desea poner como adyacente del vertice " + controladora.imprimirConcreto(padre-1) + ":");

                        controladora.imprimir();

                        int vertice = sc.nextInt();

                        boolean flag3 = false;

                        while (flag3 == false) {

                            controladora.añadirAdyacentes(vertice-1, padre-1);

                            flag3 = true;

                        }

                        flag2 = true;

                        controladora.imprimirAdyacentes(padre-1);

                    }


                    break;

                case 3:

                    controladora.comprobarConectividad();

                    break;
                case 4:

                    System.out.println("Gracias por usar el programa vuelva pronto.");

                    stopFlag = true;

                    break;
                default:

                    System.out.println("Ingrese una opción valida.");

                    break;

            }
        }
    }

}
