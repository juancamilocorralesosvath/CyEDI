package Exceptions;

public class VertexNotFoundException extends RuntimeException{
    public VertexNotFoundException(String message){
        super(message);
    }
}

