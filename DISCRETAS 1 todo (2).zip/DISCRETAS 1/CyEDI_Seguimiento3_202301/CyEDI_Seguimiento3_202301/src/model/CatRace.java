package model;

public enum CatRace {
	persian, ragdoll, siamese
}
