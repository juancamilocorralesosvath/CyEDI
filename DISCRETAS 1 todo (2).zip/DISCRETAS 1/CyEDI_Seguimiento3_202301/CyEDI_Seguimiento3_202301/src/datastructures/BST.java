package datastructures;

public class BST<k, T> implements IBinarySearchTree<K, T> {

    private   K nombreGato;
    private   T nodo ;

    public BST (K primero, T segundo){
        this.primero= primero;
        this.segundo = segundo;
    }


    public T getRoot(){



    };

    public T search(K key){

    };
    public void insert(K key, T value){

    };
    public T delete(K key){

    };
    public String inOrder(){

    };


}