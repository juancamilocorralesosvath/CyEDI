package GrafoMatriz;

import java.util.List;

public interface InterfaceGrafoMatriz<T> {


    public void agregarVertice(T vertice);
    public void agregarArista(T origen, T destino);
    public boolean[][] obtenerMatrizAdyacencia();
    public int obtenerGrado(T vertice);

    List<T> obtenerAdyacentes(T vertice);
}
