package GrafoMatriz;

import java.util.ArrayList;
import java.util.List;

public class GrafoConMatriz<T> implements InterfaceGrafoMatriz<T> {

    private List<T> vertices;
    private boolean[][] matrizAdyacencia;

    public GrafoConMatriz() {
        vertices = new ArrayList<>();
        matrizAdyacencia = new boolean[0][0];
    }

    @Override
    public void agregarVertice(T vertice) {
        // Agregamos el vértice a la lista de vértices
        vertices.add(vertice);

        // Creamos una nueva matriz de adyacencia con una fila y una columna más
        boolean[][] nuevaMatrizAdyacencia = new boolean[vertices.size()][vertices.size()];

        // Copiamos los valores de la matriz anterior a la nueva matriz
        for (int i = 0; i < matrizAdyacencia.length; i++) {
            for (int j = 0; j < matrizAdyacencia.length; j++) {
                nuevaMatrizAdyacencia[i][j] = matrizAdyacencia[i][j];
            }
        }

        // Actualizamos la referencia a la matriz de adyacencia
        matrizAdyacencia = nuevaMatrizAdyacencia;
    }

    @Override
    public void agregarArista(T origen, T destino) {
        int indiceOrigen = vertices.indexOf(origen);
        int indiceDestino = vertices.indexOf(destino);
        matrizAdyacencia[indiceOrigen][indiceDestino] = true;
    }

    @Override
    public boolean[][] obtenerMatrizAdyacencia() {
        return matrizAdyacencia;
    }

    @Override
    public int obtenerGrado(T vertice) {
        int indice = vertices.indexOf(vertice);
        int grado = 0;
        for (int i = 0; i < matrizAdyacencia.length; i++) {
            if (matrizAdyacencia[indice][i]) {
                grado++;
            }
        }
        return grado;
    }

    @Override
    public List<T> obtenerAdyacentes(T vertice) {
        int indice = vertices.indexOf(vertice);
        List<T> adyacentes = new ArrayList<>();
        for (int i = 0; i < matrizAdyacencia.length; i++) {
            if (matrizAdyacencia[indice][i]) {
                adyacentes.add(vertices.get(i));
            }
        }
        return adyacentes;
    }
}