package GrafoListas;

import java.util.List;

public interface InterfaceGrafoListas<T> {
    public void agregarVertice(T vertice);

    public void agregarArista(T origen, T destino);

    public List<T> obtenerAdyacentes(T vertice);
    public int obtenerGrado(T vertice);
}
