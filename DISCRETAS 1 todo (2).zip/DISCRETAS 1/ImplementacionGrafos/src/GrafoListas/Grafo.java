package GrafoListas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Grafo<T> implements InterfaceGrafoListas {

    private Map<T, List<T>> adjList;

    public Grafo() {
        adjList = new HashMap<>();
    }

    @Override
    public void agregarVertice(Object vertice) {
        adjList.put((T) vertice, new ArrayList<>());
    }

    @Override
    public void agregarArista(Object origen, Object destino) {
        adjList.get(origen).add((T) destino);
        adjList.get(destino).add((T) origen);
    }

    @Override
    public List obtenerAdyacentes(Object vertice) {
        return adjList.get(vertice);
    }

    @Override
    public int obtenerGrado(Object vertice) {
        return adjList.get(vertice).size();
    }
}