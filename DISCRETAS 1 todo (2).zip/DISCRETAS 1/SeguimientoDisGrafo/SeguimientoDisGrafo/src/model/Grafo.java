package model;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Grafo<T> {
	
	private Node<T> vertice;
	ArrayList<Node<T>> listaVertices;
	private Queue<Node<T>> queue;
	ArrayList<Arista<T>> listaAristas;
	
	 public Grafo(){
		 
		 this.vertice = vertice;
		 listaVertices = new ArrayList<Node<T>>() ;
		 queue = new LinkedList<Node<T>>();
		 listaAristas = new ArrayList<Arista<T>>() ;
		 
	        
	 }
	
	 public Node<T> getVertice() {
		 
		 return vertice;
	 
	 }
	 
	 
	 public void setVertice(Node <T> vertice) {
		 
	     this.vertice = vertice;
	        
	 }
	 
	 public void añadirVertice(Node<T> vertice) {
		 
		 listaVertices.add(vertice);
		 
	 }
	 
	 public void bfs(int verticeInicial) {
		 
		 for(int i = 0; i < listaVertices.size(); i++) {
			 
			 listaVertices.get(i).setColor(Color.BLANCO);
			 listaVertices.get(i).setDistancia(-1);
			 listaVertices.get(i).setPadre(null);
			 
		 }
		 
		 listaVertices.get(verticeInicial).setColor(Color.GRIS);
		 listaVertices.get(verticeInicial).setDistancia(0);
		 listaVertices.get(verticeInicial).setPadre(null);
		 
		 queue.add(listaVertices.get(verticeInicial));				 
		 
		 while(queue.isEmpty() == false) {		
			 
			 Node<T> temp = queue.remove();
			 
			 if(temp != null) {
				 
				 for(int i = 0; i < temp.getAdyacentes().size(); i++) {
				 
					 if(temp.getAdyacentes().get(i).getColor() == Color.BLANCO){
					 
						 temp.getAdyacentes().get(i).setColor(Color.GRIS);
						 temp.getAdyacentes().get(i).setDistancia(temp.getDistancia()+1);
						 temp.getAdyacentes().get(i).setPadre(temp);
						 queue.add(temp.getAdyacentes().get(i));
					 
					 }
				 
				 }					 
			 
				 temp.setColor(Color.NEGRO);
			 
			 }
			 
		 }		 
		 
	 }
	 
	
	 
	 
	 
	
}
