import java.io.*;
import java.util.*;

public class Main {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Avl tree = new Avl();

        int n = scanner.nextInt();

        for (int i = 0; i < n; i++) {
            int val = scanner.nextInt();
            tree.insert(val);
        }
        int val = scanner.nextInt();
        tree.insert(val);
        tree.inorder();
        System.out.println("");
        tree.preoOrder();
    }

}
class Avl {
    private Node root;

    public void insert(int key) {
        root = insertNode(root, key);
    }

    private Node insertNode(Node node, int key) {
        if (node == null) {
            return new Node(key);
        }
        if (key < node.key) {
            node.left = insertNode(node.left, key);
        } else if (key > node.key) {
            node.right = insertNode(node.right, key);
        } else {
            return node;
        }

        node.height = 1 + Math.max(height(node.left), height(node.right));


        return rebalance(node, key);
    }
    private Node rebalance(Node node, int key) {

            int balance = getBalance(node);

            if (balance > 1 && key < node.left.key) {
                return rightRotate(node);
            }


            if (balance < -1 && key > node.right.key) {
                return leftRotate(node);
            }


            if (balance > 1 && key > node.left.key) {
                node.left = leftRotate(node.left);
                return rightRotate(node);
            }


            if (balance < -1 && key < node.right.key) {
                node.right = rightRotate(node.right);
                return leftRotate(node);
            }
        return node;
    }
    private int getBalance(Node node) {
        if (node == null) {
            return 0;
        }

        return height(node.left) - height(node.right);
    }
    private Node rightRotate(Node node) {
        Node left = node.left;
        Node right = left.right;


        left.right = node;
        node.left = right;


        node.height = 1 + Math.max(height(node.left), height(node.right));
        left.height = 1 + Math.max(height(left.left), height(left.right));

        return left;
    }
    private Node leftRotate(Node node) {
        Node right = node.right;
        Node left = right.left;

        right.left = node;
        node.right = left;

        node.height = 1 + Math.max(height(node.left), height(node.right));
        right.height = 1 + Math.max(height(right.left), height(right.right));

        return right;
    }
    private int height(Node node) {
        if (node == null) {
            return 0;
        }

        return node.height;
    }
    public void inorder() {
        outInOrder(root);
    }

    private void outInOrder(Node node){
        if (node == null) {
            return;
        }
        outInOrder(node.left);
        System.out.print(node.key +"(BF="+getBalance(node)+") ");
        outInOrder(node.right);
    }
    public void preoOrder() {
        outPreOrder(root);
    }
    private void outPreOrder(Node node){
        if (node == null) {
            return;
        }
            System.out.print(node.key + "(BF=" + getBalance(node) + ") ");
            outPreOrder(node.left);
            outPreOrder(node.right);
    }
}
class Node {
    int key;
    int height;
    Node left;
    Node right;

    Node(int key) {
        this.key = key;
        this.height = 1;
    }
}