import java.util.Scanner;
class Main {
     public static void main(String[] args) {
        Arbol arbol = new Arbol();
        Scanner lector= new Scanner(System.in);
         int puntaje=0;
         int menu=0;
         
        while (menu!=5){
        System.out.println("\nBienvenido a EA : \n1. Agregar registro\n2. Buscar registro por puntaje\n3. Ver puntajes de menor a mayor\n4. Ver TOP 10, de mayor a menor\n5. Salir");
        menu=lector.nextInt();
 
        switch (menu){
            case 1:
            System.out.println("Escribe el nombre del jugador: ");
            String nombre=lector.nextLine();
            System.out.println("Escribe el puntaje del jugador: ");
            puntaje=lector.nextInt();
            arbol.insertar(puntaje);
            break;

            case 2:
            System.out.println("Escribe el puntaje a buscar: ");
            int buscar=lector.nextInt();
            System.out.println("Existe en el arbol? "+arbol.existe(buscar));
            arbol.mostrarBusqueda(null, puntaje, puntaje);
            break;

            case 3:
            System.out.println("Recorriendo postorden:");
            arbol.postorden();
            break;

            case 4:
            System.out.println("Top 10 Records:");
            arbol.preorden();       
            break;
        }
        }
    
    }
}