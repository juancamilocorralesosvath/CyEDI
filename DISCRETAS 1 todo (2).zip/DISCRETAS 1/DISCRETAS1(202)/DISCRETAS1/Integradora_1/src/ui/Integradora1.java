package ui;
import java.util.Scanner;
import model.Lista;
import model.Arbol;

public class Integradora1 {
 
static Scanner lector = new Scanner(System.in);   
    public static void main (String args []) throws InterruptedException {
        Lista lista = new Lista();
        Arbol arbol = new Arbol();

        for (int i=0;i<64;i++){
            String valor="x";
            lista.agregarAlFinal(valor);
        }
        
        long inicio = System.currentTimeMillis();

        int menu=0;

        while (menu!=3){
        System.out.println("\nQue deseas hacer? \n1) Nueva Partida \n2) Ver puntaje \n3) Salir");
        menu=lector.nextInt();
  
            int fila=0;
            int columna=0;
            int menu2=0;
            int tipoT=0;
            int contaTuberias=0;
            double tiempo=0;
            int mostrarP=0;
            String nombre="";
            int posicion=0;

        switch (menu) {
            case 1:
            inicio = System.currentTimeMillis();
            System.out.print("\nEscribe Tu NickName: "); 
        
            nombre=lector.nextLine();

            lector.next();
            
            //ASIGNAR AL AZAR LA LETRA F
            int posicion1 = (int)(Math.random()*64+1);
            String valor = "F";
            lista.editarPorPosicion(posicion1, valor);

            //ASIGNAR AL AZAR LA LETRA D
            int posicion2 = (int)(Math.random()*64+1);
            valor = "D";
            lista.editarPorPosicion(posicion2, valor);

            //IMPRIMIR EL 
            lista.listar();

    while (menu2!=3)
            { 
            System.out.println("\nQue deseas hacer? \n1) Colocar tuberia \n2) Simular la Corriente  \n3) Salir");
            menu2=lector.nextInt();
                
            switch (menu2)
            {
            case 1: 
            colocarTuberia(fila, columna, tipoT, valor, posicion, lista, contaTuberias,posicion1,posicion2);
            break;

            case 2:
            //PARA SIMULAR COMO SE VERIA UNA TUBERIA
            validacionT(posicion1, posicion2, menu2);
            simularTuberia(fila,columna,tipoT,valor,posicion,lista);

            break;
        }
        }
            break;
            case 2:
            double puntajeF=0;

             Thread.sleep(2000);
         
             long fin = System.currentTimeMillis();
         
             tiempo = (double)((fin - inicio)/1000);
             System.out.println("Su tiempo es "+tiempo);

             puntajeF=contaTuberias*100-(60-tiempo)*10;
             
             arbol.insertar(puntajeF);

            System.out.println("Su puntaje es de "+puntajeF);
            System.out.println("Tabla Puntajes: ");

            arbol.postorden();

            arbol.getMenores(puntajeF, null);
            break;
            
        }
    }
    }

    public static void colocarTuberia(int fila , int columna,int tipoT,String valor,int posicion,Lista lista,int contaTuberias,int posicion1,int posicion2){
            System.out.println("Escribe la fila para poner la tuberia: ");
            fila=lector.nextInt();

            System.out.println("Escribe la columna para poner la tuberia: ");
            columna=lector.nextInt();

            posicion = fila+columna*8;

            System.out.println("¿Que tipo de tuberia desea? \n1. =  \n2. || \n3. o");
            tipoT=lector.nextInt();

            //CONTADOR PARA LAS TUBERIAS
            contaTuberias=contaTuberias+1; 

            if (tipoT==1 && posicion!=posicion1 && posicion!=posicion2)
            {
            valor = "=";
            lista.editarPorPosicion(posicion, valor);
            } else if (tipoT==2 && posicion!=posicion1 && posicion!=posicion2)
            {
            valor = "||";
            lista.editarPorPosicion(posicion, valor);
            } else if (tipoT==3 && posicion!=posicion1 && posicion!=posicion2)
            {
             valor = "o";
             lista.editarPorPosicion(posicion, valor);
            } else{
            System.out.println("EL TUBO PRINCIPAL NO PUEDE SER MODIFICADO");
        }
            lista.listar();   
    }

    public static void simularTuberia(int fila , int columna,int tipoT,String valor,int posicion,Lista lista ){
        System.out.println("Escribe la fila para simular la tuberia: ");
        fila=lector.nextInt();
        System.out.println("Escribe la columna para simular la tuberia: ");
        columna=lector.nextInt();
        posicion =(columna*8)+fila;
        System.out.println("¿Que tipo de tuberia desea? \n1. =  \n2. || \n3. o");
        tipoT=lector.nextInt();
         
        if (tipoT==1){
        valor = "=";
        }

        if (tipoT==2){
        valor = "||";
        }

        if (tipoT==3){
         valor = "o";
        }
        
        lista.editarPorPosicion(posicion, valor);
        lista.listar();
        valor="x";
        lista.editarPorPosicion(posicion, valor);
       
    }

    public static void validacionT(int posicion1,int posicion2,int menu2)
    {
    boolean valido;

    if (valido=true){
     System.out.println(" ¡ La tuberia esta correctamente posicionada , has ganado !");
     menu2=3;
    } else {
    System.out.println("La tuberia tiene fugas , ¡Intenta denuevo! ");
    }
    }

   /* 
    public static double Puntuacion(int contaTuberias, double tiempo,long inicio,Arbol arbol ) throws InterruptedException {
        
        double puntajeF=0;

        Thread.sleep(2000);
         
        long fin = System.currentTimeMillis();
         
        tiempo = (double) ((fin - inicio)/1000);
        System.out.println("Su tiempo es "+tiempo);

        puntajeF=contaTuberias*100-(60-tiempo)*10;
        arbol.insertar(new NodoArbol(nombre,puntajeF));

        return puntajeF;
    } */
    
}