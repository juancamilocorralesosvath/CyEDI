
package model;

public class Lista {
    private Nodo inicio;
    private int tamanio;

    public void Lista(){
        inicio = null;
        tamanio = 0;
    }

    public boolean esVacia(){
        return inicio == null;
    }

    public int getTamanio(){
        return tamanio;
    }
    
    public void agregarAlFinal(String valor){
        Nodo nuevo = new Nodo();
        nuevo.setValor(valor);
        if (esVacia()) {
            inicio = nuevo;
        } else{
            Nodo aux = inicio;
            while(aux.getSiguiente() != null){
                aux = aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
        tamanio++;
    }
 
    public void agregarAlInicio(String valor){
        Nodo nuevo = new Nodo();
        nuevo.setValor(valor);
        if (esVacia()) {
            inicio = nuevo;
        } else{
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
        }
        tamanio++;
    }
    
    public void editarPorPosicion(int posicion , String valor){


        if(posicion>=0 && posicion<tamanio){
            if(posicion == 0){
                inicio.setValor(valor);
            }
            else{
                Nodo aux = inicio;
                for (int i = 0; i < posicion; i++) {
                    aux = aux.getSiguiente();
                }
                aux.setValor(valor);
            }
        }
    }
    
    public void listar(){
        if (!esVacia()) {
            Nodo aux = inicio;
            int i = 0;
            while(aux != null){
                System.out.print("[  " + aux.getValor() + "  ]");
                aux = aux.getSiguiente();
                i++;
                if (i==8){
                    System.out.print("\n"); 
                }
                if (i==16){
                    System.out.print("\n"); 
                }
                if (i==24){
                    System.out.print("\n"); 
                }
                if (i==32){
                    System.out.print("\n"); 
                }
                if (i==40){
                    System.out.print("\n"); 
                }
                if (i==48){
                    System.out.print("\n"); 
                }
                if (i==56){
                    System.out.print("\n"); 
                }

            }
        }
    }
}