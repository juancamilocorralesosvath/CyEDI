package model;

public class Arbol {
    private NodoArbol raiz;

    public Arbol() {

    }

    public boolean existe(int busqueda) {
        return existe(this.raiz, busqueda);
    }

    private boolean existe(NodoArbol n, int busqueda) {
        if (n == null) {
            return false;
        }
        if (n.getDato() == busqueda) {
            return true;
        } else if (busqueda < n.getDato()) {
            return existe(n.getIzquierda(), busqueda);
        } else {
            return existe(n.getDerecha(), busqueda);
        }

    }

    public void insertar(double puntajeF) {
        if (this.raiz == null) {
            this.raiz = new NodoArbol(puntajeF);
        } else {
            this.insertar(this.raiz, puntajeF);
        }
    }

    private void insertar(NodoArbol padre, double puntajeF) {
        if (puntajeF > padre.getDato()) {
            if (padre.getDerecha() == null) {
                padre.setDerecha(new NodoArbol(puntajeF));
            } else {
                this.insertar(padre.getDerecha(), puntajeF);
            }
        } else {
            if (padre.getIzquierda() == null) {
                padre.setIzquierda(new NodoArbol(puntajeF));
            } else {
                this.insertar(padre.getIzquierda(), puntajeF);
            }
        }
    }
public int i;
    private void preorden(NodoArbol n) {
       for (i=0;i<10 ; i++){ 
            n.imprimirDato();
            n.getIzquierda();
            n.getDerecha();
    }
    }

    
    private void inorden(NodoArbol n) {
        
        if (n != null) {
            inorden(n.getIzquierda());
            n.imprimirDato();
            inorden(n.getDerecha());
        }
    
    }

    private void postorden(NodoArbol n) {
        if (n != null) {
            postorden(n.getIzquierda());
            postorden(n.getDerecha());
            n.imprimirDato();
        }
    }
    public int getMenores(double puntajeF, NodoArbol n)
    {
        int contador=0;
        if(n!=null){
            if(n.getDato()<puntajeF)
                contador++;
        }
        if(n.getIzquierda()!=null){
            contador +=getMenores(puntajeF,n.getIzquierda());
        }
        if(n.getDerecha()!=null){
            contador +=getMenores(puntajeF,n.getDerecha());
        }
        return contador;
    }

    public void mostrarBusqueda(NodoArbol n , int puntaje, int dato){
        if (n!= null) {
            dato=puntaje;
         n.imprimirDato();
        }
    }
    public void preorden() {
        this.preorden(this.raiz);
    }

    public void inorden() {
        this.inorden(this.raiz);
    }

    public void postorden() {
        this.postorden(this.raiz);
    }
}