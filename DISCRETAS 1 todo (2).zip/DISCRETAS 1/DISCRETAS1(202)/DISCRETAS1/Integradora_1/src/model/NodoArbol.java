package model;
class NodoArbol {
    
    private double dato;
    private String nombreF;

    private NodoArbol izquierda, derecha;


    public NodoArbol(double puntajeF) {
        this.dato = puntajeF;
  

        this.izquierda = this.derecha = null;
    }

    public double getDato() {
        return dato;
    }
    public String getNombreF(){
        return nombreF;
    }
    public NodoArbol getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(NodoArbol izquierda) {
        this.izquierda = izquierda;
    }

    public NodoArbol getDerecha() {
        return derecha;
    }

    public void setDerecha(NodoArbol derecha) {
        this.derecha = derecha;
    }

    public void imprimirDato() {
        System.out.println(this.getDato());
    }

}