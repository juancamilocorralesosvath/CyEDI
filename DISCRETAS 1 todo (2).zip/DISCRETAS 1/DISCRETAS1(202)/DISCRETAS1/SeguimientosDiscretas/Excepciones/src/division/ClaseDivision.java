package division;

import java.time.LocalDateTime;
import java.util.Scanner;

public class ClaseDivision {

    public static void main(String[] args) {
        int switch1=0;

        while (switch1!=3){
        try {

            int valor1, valor2, resultado,cedula;
            

            System.out.println("\nQue desea registrar? \n1) Automobil  \n2)Motocicleta ");
            Scanner entrada = new Scanner(System.in);

            switch (switch1){
                case 1:
            
            System.out.print("Dame la placa del Automobil: ");
            valor1 = entrada.nextInt();
            
            LocalDateTime locaDate = LocalDateTime.now();
            int hours  = locaDate.getHour();
            System.out.println("Hora actual : " +hours);

            System.out.println("Introduce la cedula del propietario:");
            cedula = entrada.nextInt();

            break;

                case 2:

            System.out.print("Dame la placa de la moto: ");
            valor2 = entrada.nextInt();

            locaDate = LocalDateTime.now();
            int hoursM  = locaDate.getHour();
            System.out.println("Hora actual : " +hoursM);
            
            break;

               case 3:
              System.out.println("Hasta Luego!!");
              break;
            }
            
  
        
        } catch (Exception e) {
            System.out.println("Error!!!! " + e);
        } finally {
            System.out.println("Operación concluida!!");
        }
        }
    }
}
