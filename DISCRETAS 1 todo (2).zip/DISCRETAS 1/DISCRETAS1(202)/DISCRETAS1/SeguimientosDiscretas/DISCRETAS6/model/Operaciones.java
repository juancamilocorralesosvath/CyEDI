package model;

public interface Operaciones<T> {
	void insertar();
	void eliminar();
	void union();
	boolean pertenece();
	void interseccion();

}