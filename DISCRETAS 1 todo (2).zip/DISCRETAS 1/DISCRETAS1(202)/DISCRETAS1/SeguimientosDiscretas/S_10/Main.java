public class Main {
	public static void main(String[] args)
	{
		Map<String, Integer> map = new Map<>();
		map.add("Sara", 13467);
		map.add("Miguel", 230482);
		map.add("Laura", 42039);
		map.add("Santiago", 540029);
		System.out.println(map.size());
		System.out.println(map.remove("Sara"));
		System.out.println(map.remove("Laura"));
		System.out.println(map.size());
	}
}

