import java.util.ArrayList;
import java.util.HashMap;

/*
 * Cada arista se puede identificar con los índices de la matriz de adyacencias.
 * @param <T> Tipo de objetos asociado a los vértices.
 * @param <N> Tipo numérico asociado a las aristas para representar los pesos.
 */

public class Grafo<T, N extends Number> {

    private ArrayList<ArrayList<Arista<N>>> matrizAdyacencias;
    private HashMap<Integer, ArrayList<Vertice<T>>> listasAdyacencias;
    private ArrayList<Vertice<T>> vertices;
    private int nAristas;
    private int nVertices;
    private ArrayList<Integer> grados;

    
    private void aumentarGrado(int id) throws IllegalArgumentException {
        if (!(this.existeIdVertice(id))) {
            throw new IllegalArgumentException("Error al aumentar grado: el vértice no existe.");
        }
        this.grados.set(id, this.grados.get(id) + 1);
    }

    private void disminuirGrado(int id) throws IllegalArgumentException {
        if (!(this.existeIdVertice(id))) {
            throw new IllegalArgumentException("Error al disminuir grado: el vértice no existe.");
        }
        this.grados.set(id, this.grados.get(id) - 1);
    }

    public Grafo() {
        this.matrizAdyacencias = new ArrayList<>();
        this.matrizAdyacencias.add(new ArrayList<Arista<N>>());
        this.listasAdyacencias = new HashMap<>();
        this.listasAdyacencias.put(0, new ArrayList<Vertice<T>>());
        this.vertices = new ArrayList<>();
        this.vertices.add(new Vertice<T>());
        this.matrizAdyacencias.get(0).add(null);
        this.nVertices = 1;
        this.grados = new ArrayList<>();
        this.grados.add(0);
    }

    public Grafo(int n) throws IllegalArgumentException {
        this();
        if (n < 1) {
            throw new IllegalArgumentException("Error al crear grafo: n < 1");
        }
        for (int i = 0; i < n; i++) {
            if (i > 0) {
                this.vertices.add(new Vertice<T>());
                this.nVertices++;
                this.matrizAdyacencias.add(new ArrayList<Arista<N>>());
                this.listasAdyacencias.put(i, new ArrayList<Vertice<T>>());
                this.grados.add(0);
            }
            for (int j = 0; j < n; j++) {
                if (!(i == 0 && j == 0)) {
                    this.matrizAdyacencias.get(i).add(null);
                }
            }
        }
    }

    public Grafo(Grafo<T,N> original) {
        this();

        this.nAristas = original.nAristas;
        this.nVertices = original.nVertices;

        int n = original.nVertices;
        for (int i = 0; i < n; i++) {
            Vertice<T> v = new Vertice<>(original.vertices.get(i));
            Integer grado = new Integer((int) original.grados.get(i));
            if (i == 0) {
                this.vertices.set(0, v);
                this.grados.set(0, grado);
            } else {
                this.vertices.add(v);
                this.grados.add(grado);
                this.matrizAdyacencias.add(new ArrayList<Arista<N>>());
            }

            for (int j = 0; j < n; j++) {
                Arista<N> a = null;
                if (i != j && original.adyacentes(i, j)) {
                    a = new Arista<N>(original.arista(i, j));
                }
                if (i == 0 && j == 0) {
                    this.matrizAdyacencias.get(0).set(0, a);
                } else {
                    this.matrizAdyacencias.get(i).add(a);
                }
            }
        }

        for (int i = 0; i < this.nVertices; i++) {
            ArrayList<Vertice<T>> nuevaLista = new ArrayList<>();
            for (int j = 0; j < this.nVertices; j++) {
                if (i != j && this.adyacentes(i, j)) {
                    nuevaLista.add(this.vertice(j));
                }
            }
            this.listasAdyacencias.put(i, nuevaLista);
        }
    }


    public ArrayList<ArrayList<Arista<N>>> matrizAdyacencias() {
        return this.matrizAdyacencias;
    }

    public HashMap<Integer, ArrayList<Vertice<T>>> listasAdyacencias() {
        return this.listasAdyacencias;
    }

    public int numVertices() {
        return this.nVertices;
    }

    public int numAristas() {
        return this.nAristas;
    }

    private boolean existeIdVertice(int id) {
        return id >= 0 && id < this.nVertices;
    }

    private boolean existeVertice(Vertice v) {
        return this.vertices.contains(v);
    }

    public int idVertice(Vertice v) throws IllegalArgumentException {
        if (!this.vertices.contains(v)) {
            throw new IllegalArgumentException("Error al consultar el identificador del vértice: el vértice no existe.");
        }

        return this.vertices.indexOf(v);
    }

    public int gradoVertice(int id) throws IllegalArgumentException {
        if (!this.existeIdVertice(id)) {
            throw new IllegalArgumentException("Error al consultar grado vértice: identificador no válido.");
        }
        return this.grados.get(id);
    }

    public ArrayList<Arista> aristasIncidentes(int id) throws IllegalArgumentException {
        if (!this.existeIdVertice(id)) {
            throw new IllegalArgumentException("Error al consultar aristas incidentes: id de vértice no existe.");
        }
        ArrayList<Arista> aristas = new ArrayList<>();
        for (int j = 0; j < this.nVertices; j++) {
            if (id != j && this.adyacentes(id, j)) {
                aristas.add(this.arista(id, j));
            }
        }
        return aristas;
    }

    private ArrayList<Vertice> verticesAdyacentes(int id) throws IllegalArgumentException {
        if (!this.existeIdVertice(id)) {
            throw new IllegalArgumentException("Error al consultar vértices adyacentes: id de vértice no existe.");
        }
        ArrayList<Vertice> vAd = new ArrayList<>();
        for (int j = 0; j < this.nVertices; j++) {
            if (id != j && this.adyacentes(id, j)) {
                vAd.add(this.vertice(j));
            }
        }
        return vAd;
    }

    public ArrayList<Vertice> verticesAdyacentes(Vertice v) throws IllegalArgumentException {
        if (!this.existeVertice(v)) {
            throw new IllegalArgumentException("Error al consultar vértices adyacentes: vértice no existe.");
        }
        return this.verticesAdyacentes(this.idVertice(v));
    }

    public ArrayList<Integer> camino(int idOrigen, int idDestino) throws IllegalArgumentException {
        if (!(this.existeIdVertice(idOrigen) && this.existeIdVertice(idDestino))) {
            throw new IllegalArgumentException("Error en camino(int,int): algún vértice no existe.");
        }
        if (idOrigen == idDestino) {
            throw new IllegalArgumentException("Error en camino(int,int): deben ser identificadores diferentes.");
        }

        int[] predecesores = new int[this.nVertices];

        ArrayList<Vertice> Q = new ArrayList<>();
        boolean[] visitado = new boolean[this.nVertices];
        for (int i = 0; i < visitado.length; i++) {
            visitado[i] = false;
        }
        Vertice v = this.vertices.get(idDestino);
        Q.add(v);
        visitado[idDestino] = true;
        Vertice t = null;
        while (!Q.isEmpty() && idVertice(t = Q.get(0)) != idOrigen) {
            Q.remove(t);
            for (Vertice u : this.verticesAdyacentes(t)) {
                if (!visitado[this.idVertice(u)]) {
                    predecesores[this.idVertice(u)] = this.idVertice(t);
                    visitado[this.idVertice(u)] = true;
                    Q.add(u);
                }
            }
        }
        ArrayList<Integer> camino = new ArrayList<>();
        int id = idVertice(t);
        if (id == idOrigen) {
            while (id != idDestino) {
                camino.add(id);
                id = predecesores[id];
            }
            camino.add(id);
        }
        return camino;
    }

    public boolean conectaTodosVertices(ArrayList<Arista> aristas) throws IllegalArgumentException {
        ArrayList<Vertice> V = new ArrayList<>();
        int visitados = 0;
        for (int i = 0; i < aristas.size() && visitados < this.nVertices; i++) {
            Arista a = aristas.get(i);
            if (a == null) {
                throw new IllegalArgumentException("Error al comprobar arista: referencia nula a la arista.");
            }
            int idOrigen = a.origen();
            int idDestino = a.destino();
            if (idOrigen == idDestino) {
                throw new IllegalArgumentException("Error al comprobar arista: la arista tiene el mismo origen y destino.");
            }
            if (!(this.existeIdVertice(idOrigen) && this.existeIdVertice(idDestino))) {
                throw new IllegalArgumentException("Error al comprobar arista: algún vértice no existe.");
            }

            Vertice v1 = this.vertice(idOrigen);
            Vertice v2 = this.vertice(idDestino);
            if (!V.contains(v1)) {
                V.add(v1);
                visitados++;
            }
            if (!V.contains(v2)) {
                V.add(v2);
                visitados++;
            }
        }
        return visitados == this.nVertices;
    }

    public boolean completo() {
        boolean esCompleto = true;
        for (int i = 0; i < this.nVertices && esCompleto; i++) {
            for (int j = i + 1; j < this.nVertices; j++) {
                if (this.matrizAdyacencias.get(i).get(j) == null) {
                    esCompleto = false;
                }
            }
        }
        return esCompleto;
    }

    public boolean conexo() {
        //BFS
        ArrayList<Vertice> Q = new ArrayList<>();
        Q.add(this.vertices.get(0));
        boolean[] visitado = new boolean[this.nVertices];
        for (int i = 0; i < visitado.length; i++) {
            visitado[i] = false;
        }
        visitado[0] = true;
        int countVis = 1;
        while (!Q.isEmpty()) {
            Vertice t = Q.get(0);
            Q.remove(t);
            for (Vertice u : this.verticesAdyacentes(t)) {
                if (!visitado[this.idVertice(u)]) {
                    visitado[this.idVertice(u)] = true;
                    countVis++;
                    Q.add(u);
                }
            }
        }
        return countVis == this.nVertices;
    }

    public void anadirVertice(Vertice v) throws IllegalArgumentException {
        if (this.vertices.contains(v)) {
            throw new IllegalArgumentException("Error al añadir vértice: el vértice ya existe.");
        }
        this.vertices.add(v);
        this.matrizAdyacencias.add(new ArrayList<Arista<N>>());
        this.grados.add(0);
        this.listasAdyacencias.put(this.nVertices, new ArrayList<Vertice<T>>());

        this.nVertices++;
        for (int i = 0; i < this.nVertices; i++) {
            int dif = this.nVertices - this.matrizAdyacencias.get(i).size();
            for (int j = 0; j < dif; j++) {
                this.matrizAdyacencias.get(i).add(null);
            }
        }
    }

    public void modificarVertice(int id, Vertice v) throws IllegalArgumentException {
        if (!this.existeIdVertice(id)) {
            throw new IllegalArgumentException("Error al modificar vértice: identificador no válido.");
        }

        HashMap<Integer, ArrayList<Vertice<T>>> listas = this.listasAdyacencias;
        for (int i = 0; i < this.nVertices; i++) {
            ArrayList<Vertice<T>> lista = listas.get(i);
            if (i != id) {
                Vertice<T> w = this.vertice(id);
                if (lista.contains(w)) {
                    lista.set(lista.indexOf(w), v);
                } else {
                    lista.add(v);
                }
            }
        }
        this.vertices.set(id, v);
    }

    public Vertice vertice(int id) throws IllegalArgumentException {
        if (!this.existeIdVertice(id)) {
            throw new IllegalArgumentException("Error al consultar vértice: identificador no válido.");
        }
        return this.vertices.get(id);
    }

    public boolean adyacentes(int idOrigen, int idDestino) throws IllegalArgumentException {
        if (!(this.existeIdVertice(idOrigen) && this.existeIdVertice(idDestino))) {
            throw new IllegalArgumentException("Error en adyacentes(int,int): algún vértice no existe.");
        }
        if (idOrigen == idDestino) {
            throw new IllegalArgumentException("Error en adyacentes(int,int): deben ser identificadores diferentes.");
        }
        return this.matrizAdyacencias.get(idOrigen).get(idDestino) != null || this.matrizAdyacencias.get(idDestino).get(idOrigen) != null;
    }

    public Arista arista(int idOrigen, int idDestino) throws IllegalArgumentException {
        if (!(this.existeIdVertice(idOrigen) && this.existeIdVertice(idDestino))) {
            throw new IllegalArgumentException("Error al consultar una arista: algún vértice no existe.");
        }
        if (idOrigen == idDestino) {
            throw new IllegalArgumentException("Error al consultar una arista: deben ser identificadores diferentes.");
        }
        if (!this.adyacentes(idOrigen, idDestino)) {
            throw new IllegalArgumentException("Error al consultar una arista: los vértices no son adyacentes.");
        }

        Arista a = this.matrizAdyacencias.get(idOrigen).get(idDestino);
        return a;
    }

    private void ponerArista(int idOrigen, int idDestino, Arista arista) throws IllegalArgumentException {
        if (!(this.existeIdVertice(idOrigen) && this.existeIdVertice(idDestino))) {
            throw new IllegalArgumentException("Error al poner una arista: algún vértice no existe.");
        }
        if (idOrigen == idDestino) {
            throw new IllegalArgumentException("Error al poner una arista: deben ser identificadores diferentes.");
        }
        if (!this.adyacentes(idOrigen, idDestino)) {
            this.aumentarGrado(idOrigen);
            this.aumentarGrado(idDestino);
        }
        //Actualizar matriz de adyacencia
        arista.modificarOrigen(idOrigen);
        arista.modificarDestino(idDestino);
        this.matrizAdyacencias.get(idOrigen).set(idDestino, arista);
        Arista inv = new Arista(arista);
        inv.modificarOrigen(idDestino);
        inv.modificarDestino(idOrigen);
        this.matrizAdyacencias.get(idDestino).set(idOrigen, inv);
        //Actualizar listas de adyacencias
        ArrayList<Vertice<T>> listAdyOri = this.listasAdyacencias.get(idOrigen);
        ArrayList<Vertice<T>> listAdyDest = this.listasAdyacencias.get(idDestino);
        Vertice origen = this.vertice(idOrigen);
        Vertice destino = this.vertice(idDestino);
        if (!listAdyOri.contains(destino)) {
            listAdyOri.add(destino);
        }
        if (!listAdyDest.contains(origen)) {
            listAdyDest.add(origen);
        }

        this.nAristas++;
    }

    public void ponerArista(Arista arista) throws IllegalArgumentException {
        if (!(this.existeIdVertice(arista.origen()) && this.existeIdVertice(arista.destino()))) {
            throw new IllegalArgumentException("Error al poner una arista: algún vértice no existe.");
        }
        if (arista.origen() == arista.destino()) {
            throw new IllegalArgumentException("Error al poner una arista: deben ser identificadores diferentes.");
        }
        this.ponerArista(arista.origen(), arista.destino(), arista);
    }


    public void eliminarArista(int idOrigen, int idDestino) throws IllegalArgumentException {
        if (!(this.existeIdVertice(idOrigen) && this.existeIdVertice(idDestino))) {
            throw new IllegalArgumentException("Error al eliminar una arista: algún vértice no existe.");
        }
        if (idOrigen == idDestino) {
            throw new IllegalArgumentException("Error al eliminar una arista: deben ser identificadores diferentes.");
        }
        if (!this.adyacentes(idOrigen, idDestino)) {
            throw new IllegalArgumentException("Error al eliminar una arista: la arista no existe.");
        }
        if (this.adyacentes(idOrigen, idDestino)) {
            this.disminuirGrado(idOrigen);
            this.disminuirGrado(idDestino);
        }
        this.matrizAdyacencias.get(idOrigen).set(idDestino, null);
        this.matrizAdyacencias.get(idDestino).set(idOrigen, null);
        ArrayList<Vertice<T>> listAdyOri = this.listasAdyacencias.get(idOrigen);
        ArrayList<Vertice<T>> listAdyDest = this.listasAdyacencias.get(idDestino);
        Vertice origen = this.vertice(idOrigen);
        Vertice destino = this.vertice(idDestino);
        listAdyOri.remove(destino);
        listAdyDest.remove(origen);

        this.nAristas--;
    }
}