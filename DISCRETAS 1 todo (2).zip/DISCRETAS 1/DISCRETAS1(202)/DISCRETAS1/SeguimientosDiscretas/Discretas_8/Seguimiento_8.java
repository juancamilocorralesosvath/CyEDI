import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;


public class Seguimiento_8 {

	private static Scanner lector;

	public static void main(String[] args) {

		Map<String, String> phoneBook = new HashMap<String, String>();

		lector = new Scanner(System.in);
		int n = lector.nextInt();
		lector.nextLine();
		
		for (int i = 0; i < n; i++) 
        {
			String name = lector.nextLine();
			String phone = lector.nextLine();

			phoneBook.put(name, phone);
		}

		while (lector.hasNext()) 
		{
			String inputName = lector.nextLine();

			if (phoneBook.containsKey(inputName)) {
				System.out.println(inputName + "=" + phoneBook.get(inputName));
			} else {
				System.out.println("Not found");
			}

		}

	}

}