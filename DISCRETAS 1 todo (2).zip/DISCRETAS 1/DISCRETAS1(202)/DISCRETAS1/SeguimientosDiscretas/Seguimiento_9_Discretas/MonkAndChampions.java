import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.InputMismatchException;
 
public class MonkAndChampions 
{
 
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {

		InputReader ir = new InputReader(System.in);
		Print p = new Print();
 
		int M = ir.nextInt();
		int N = ir.nextInt();
 
		long a[] = new long[M + 1];
 
		for (int i = 1; i <= M; i++) 
        {
			a[i] = ir.nextLong();
		}

		Heap heap = new Heap(M);
		heap.build_heap(a, M);
 
		long ans = 0;
 
		outer: while (N > 0) 
        {
			long max1 = heap.getMax(a);
			long max2 = a[1];
 
			while (max1 >= max2) {
				ans += max1;
				N--;
				max1--;
				if (N == 0)
					break outer;
 
			}
			if (max1 > 0)
				heap.add(a, max1);
 
		}
 
		p.println(ans);
 
		p.close();
 
	}
 
	private static class Heap {
		int end;
 
		public Heap(int N) 
        {
			end = N;
		}
 
		public void maxify_heap(long a[], int i, int N) {
			int left = 2 * i;
			int right = 2 * i + 1;
			int largest;
 
			if (left <= N && a[left] > a[i]) {
				largest = left;
			} else
				largest = i;
 
			if (right <= N && a[right] > a[largest])
				largest = right;
 
			if (largest != i) {
				a[largest] = a[largest] ^ a[i];
				a[i] = a[largest] ^ a[i];
				a[largest] = a[largest] ^ a[i];
				maxify_heap(a, largest, N);
			}
		}
 
		public void build_heap(long a[], int N) {
			for (int i = N / 2; i >= 1; i--) {
				maxify_heap(a, i, N);
			}
		}
 
		public void add(long a[], long val) {
			end = end + 1;
			a[end] = val;
			int i = end;
 
			while (i > 1 && a[i / 2] < a[i]) {
				a[i / 2] = a[i / 2] ^ a[i];
				a[i] = a[i / 2] ^ a[i];
				a[i / 2] = a[i / 2] ^ a[i];
				i = i / 2;
			}
 
		}
 
		public long getMax(long a[]) {
			long max = a[1];
			a[1] = a[end];
			end--;
 
			maxify_heap(a, 1, end);
 
			return max;
 
		}
 
		public void setEnd(int i) {
			end = i;
		}
	}
 
	static class InputReader {
 
		private InputStream stream;
		private byte[] buf = new byte[8192];
		private int curChar;
		private int snumChars;
		private SpaceCharFilter filter;
 
		public InputReader(InputStream stream) {
			this.stream = stream;
		}
 
		public int snext() {
			if (snumChars == -1)
				throw new InputMismatchException();
			if (curChar >= snumChars) {
				curChar = 0;
				try {
					snumChars = stream.read(buf);
				} catch (IOException e) {
					throw new InputMismatchException();
				}
				if (snumChars <= 0)
					return -1;
			}
			return buf[curChar++];
		}
 
		public int nextInt() {
			int c = snext();
			while (isSpaceChar(c))
				c = snext();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = snext();
			}
 
			int res = 0;
 
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = snext();
			} while (!isSpaceChar(c));
 
			return res * sgn;
		}
 
		public long nextLong() {
			int c = snext();
			while (isSpaceChar(c))
				c = snext();
			int sgn = 1;
			if (c == '-') {
				sgn = -1;
				c = snext();
			}
 
			long res = 0;
 
			do {
				if (c < '0' || c > '9')
					throw new InputMismatchException();
				res *= 10;
				res += c - '0';
				c = snext();
			} while (!isSpaceChar(c));
 
			return res * sgn;
		}
 
		public String readString() {
			int c = snext();
			while (isSpaceChar(c))
				c = snext();
			StringBuilder res = new StringBuilder();
			do {
				res.appendCodePoint(c);
				c = snext();
			} while (!isSpaceChar(c));
			return res.toString();
		}
 
		public boolean isSpaceChar(int c) {
			if (filter != null)
				return filter.isSpaceChar(c);
			return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
		}
 
		public interface SpaceCharFilter {
			public boolean isSpaceChar(int ch);
		}
	}
 
	static class Print {
		private final BufferedWriter bw;
 
		public Print() {
			this.bw = new BufferedWriter(new OutputStreamWriter(System.out));
		}
 
		public void print(Object object) throws IOException {
			bw.append("" + object);
		}
 
		public void println(Object object) throws IOException {
			print(object);
			bw.append("\n");
		}
 
		public void close() throws IOException {
			bw.close();
		}
	}
 
}