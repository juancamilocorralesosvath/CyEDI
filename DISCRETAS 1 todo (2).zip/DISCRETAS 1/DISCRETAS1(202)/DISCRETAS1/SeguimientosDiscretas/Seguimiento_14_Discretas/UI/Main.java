package UI;

import model.Grafo;
import model.Arista;
import model.Vertice;

/*
* @author : Manuel Herrera
*/

public class Main {

	public static void main(String[] args) {
		Grafo grafoTest = new Grafo();

		// CREAR 6 VERTICES
		Vertice[] vertices = new Vertice[6];

		// ETIQUETAS PARA LOS 6 VERTICES
		char[] etiquetas = { 'A', 'B', 'C', 'D', 'E', 'F' };

		// INT PARA LOS CICLOS
		int i = 0;

		boolean sobreescribe = true;

		System.out.println("Vertices Disponibles :");

		for (i = 0; i < vertices.length; i++) {
			vertices[i] = new Vertice(Character.toString(etiquetas[i]));
			System.out.println(vertices[i]);
		}

		// INSERT DE LAS ARISTAS
		grafoTest.insertarArista(vertices[0], vertices[1], 3); // A -> B
		grafoTest.insertarArista(vertices[0], vertices[2], 3); // A -> C
		grafoTest.insertarArista(vertices[1], vertices[2], 1); // B -> C

		grafoTest.insertarArista(vertices[3], vertices[4], 3); // D -> E
		grafoTest.insertarArista(vertices[3], vertices[5], 3); // D -> F
		grafoTest.insertarArista(vertices[4], vertices[5], 1); // E -> F

		grafoTest.insertarArista(vertices[0], vertices[3], 3); // A -> D
		grafoTest.insertarArista(vertices[2], vertices[4], 2); // C -> E

		for (i = 0; i < vertices.length; i++) {
			System.out.println("\nVecinos del " + vertices[i]);
			for (int k = 0; k < vertices[i].getContarVecinos(); k++)
				System.out.println(vertices[i].getVecino(k));
		}

		// ELIMINAR ARISTA CON C
		for (Arista arista : vertices[1].getVecinos()) {
			if (arista.getVertice2().getEtiqueta().equals("C"))
				grafoTest.eliminarArista(arista);
		}

		// ELIMINAR ARISTA CON B
		for (Arista arista : vertices[2].getVecinos()) {
			if (arista.getVertice2().getEtiqueta().equals("B"))
				grafoTest.eliminarArista(arista);
		}


	    int temp=0;
		for (i = 0; i < vertices.length; i++) {
			for (int k = 0; k < vertices[i].getContarVecinos(); k++)
				if(grafoTest.contieneLaArista(new Arista(vertices[i], vertices[k]))== true) {
                 temp=temp+1;
				}
		}
		if (temp==vertices.length){
	    System.out.println("EL GRAFO ES FUERTEMENTE CONEXO");
		}else System.out.println("EL GRAFO NO ES FUERTEMENTE CONEXO");

	}
}