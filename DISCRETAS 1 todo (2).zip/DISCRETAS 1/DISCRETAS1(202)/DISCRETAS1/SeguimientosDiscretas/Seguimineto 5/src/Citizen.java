public class Citizen {

    private int CC;
    private String name;
    private String dateBirth;
    private String cityBirth;

    private Citizen left;
    private Citizen right;

    public Citizen(int CC, String name, String dateBirth, String cityBirth) {
        this.CC = CC;
        this.name = name;
        this.dateBirth = dateBirth;
        this.cityBirth = cityBirth;
    }

    public int getCC() {
        return CC;
    }

    public void setCC(int CC) {
        this.CC = CC;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDateBirth() {
        return dateBirth;
    }

    public void setDateBirth(String dateBirth) {
        this.dateBirth = dateBirth;
    }

    public String getCityBirth() {
        return cityBirth;
    }

    public void setCityBirth(String cityBirth) {
        this.cityBirth = cityBirth;
    }

    public Citizen getLeft() {
        return left;
    }

    public void setLeft(Citizen left) {
        this.left = left;
    }

    public Citizen getRight() {
        return right;
    }

    public void setRight(Citizen right) {
        this.right = right;
    }

    public String toString(){
        return "***********************" + "\n" +
                name + "\n" +
                dateBirth + "\n" +
                CC + "\n" +
                cityBirth + "\n" +
                "***********************";
    }
}
