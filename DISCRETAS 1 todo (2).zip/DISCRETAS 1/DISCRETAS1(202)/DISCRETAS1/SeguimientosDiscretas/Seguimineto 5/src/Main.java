import java.util.*;

public class Main {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        ABB db = new ABB();

        boolean start = true;
        while(start){
            switch (menu()){
                case 1:
                    System.out.println("Incripcion de ciudadano");
                    System.out.println("Escriba el numero de cedula de la persona");
                    int CC = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Escriba el nombre completo de la persona");
                    String name = sc.nextLine();
                    System.out.println("Escriba la fecha de nacimiento, en formato dd/mm/aaaa");
                    String dateBirth = sc.nextLine();
                    System.out.println("Escriba la ciudad de nacimiento");
                    String cityBirth = sc.nextLine();
                    db.addCitizen(new Citizen(CC,name,dateBirth,cityBirth));
                    System.out.println(name + " Registrado exitosamente");
                    break;
                case 2:
                    System.out.println("Busqueda de una persona");
                    System.out.println("Indique el numero de cedula de la persona que desea buscar");
                    int cc = sc.nextInt();
                    Citizen obj = db.searchByCC(cc);
                    if(obj == null){
                        System.out.println("No se encontro a ningun ciudadano con el numero de cedula " + cc);
                    }else {
                        int iterations = db.auxSearch(cc);
                        System.out.println(obj.toString() + "\n" +
                                "Encontrado en " + iterations + " iteraciones" + "\n" +
                                "***********************" + "\n");
                    }
                    break;
                case 3:
                    System.out.println("Eliminacion de ciudadano de la base de datos");
                    System.out.println("Indique el numero de cedula del ciudadano que se quiere eliminar");
                    int Cc = sc.nextInt();
                    db.delete(Cc);
                    break;
                case 4:
                    start = false;
                    break;
            }
        }

    }

    public static int menu(){
        System.out.println(
                "********************" + "\n" +
                "Registro DANE" + "\n" +
                "********************" + "\n" +
                "(1) Inscribir un ciudadano" + "\n" +
                "(2) Consultar por cedula" + "\n" +
                "(3) Eliminar ciudadano por cedula" + "\n" +
                "(4) Salir");
        int option = sc.nextInt();
        return option;
    }

}
