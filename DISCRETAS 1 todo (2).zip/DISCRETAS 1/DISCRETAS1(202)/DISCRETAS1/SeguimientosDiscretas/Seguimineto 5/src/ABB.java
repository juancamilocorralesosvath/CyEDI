public class ABB {

    private Citizen root;

    public ABB(){
    }

    public Citizen getRoot() {
        return root;
    }

    public void setRoot(Citizen root) {
        this.root = root;
    }

    public void addCitizen(Citizen obj){
        if(root==null){
            root = obj;
        }else{
            addCitizen(obj,root);
        }
    }

    private void addCitizen(Citizen obj, Citizen current){

        if(obj.getCC()<current.getCC()){
            //izquierda
            if(current.getLeft()!=null){
                addCitizen(obj,current.getLeft());
            }else{
                current.setLeft(obj);
            }

        } else if (obj.getCC()>current.getCC()) {
            //derecha
            if (current.getRight() != null) {
                addCitizen(obj,current.getRight());
            }else{
                current.setRight(obj);
            }
        }
    }

    public Citizen searchByCC(int CC){
        return searchByCC(CC,root);
    }

    private Citizen searchByCC(int CC, Citizen current){
        if(current==null){
            return null;
        }
        if(CC<current.getCC()){
            return searchByCC(CC,current.getLeft());
        }else if(CC>current.getCC()){
            return searchByCC(CC,current.getRight());
        }else{
            return current;
        }
    }

    public int auxSearch(int CC){
        return auxSearch(CC, root, 0);
    }

    private int auxSearch(int CC, Citizen current, int n){
        if(current==null){
            return 0;
        }
        if(CC<current.getCC()){
            return auxSearch(CC,current.getLeft(), n++);
        }else if(CC>current.getCC()){
            return auxSearch(CC,current.getRight(), n++);
        }else{
            return n;
        }
    }

    public Citizen delete(int CC){
        return delete(CC,root);
    }

    private Citizen delete(int CC, Citizen current){
        if(current == null){
            return null;
        }
        if(current.getCC() == CC){
            //1. Nodo Hoja
            if(current.getLeft() == null && current.getRight() == null){
                if(current == root){
                    root = null;
                }else{

                }
                return null;
            }
            //2. Nodo solo hijo izquierdo
            else if (current.getRight() == null){
                if(current == root){
                    root = current.getLeft();
                }
                return current.getLeft();
            }
            //3. Nodo solo hijo derecho
            else if(current.getLeft() == null){
                if(current == root){
                    root = current.getRight();
                }
                return current.getRight();
            }
            //4. Nodo con dos hijos
            else{
                Citizen min = getMin(current.getRight());
                //Transferencia de valores, NUNCA de conexiones
                current.setCC(min.getCC());
                //Hacer eliminación a partir de la derecha
                Citizen subarbolDER = delete(min.getCC(), current.getRight());
                current.setRight( subarbolDER );
                return current;
            }


        }else if(CC < current.getCC()){
            Citizen subArbolIzquierdo = delete(CC, current.getLeft());
            current.setLeft(subArbolIzquierdo);
            return current;
        }else{
            Citizen subArbolDerecho = delete(CC, current.getRight());
            current.setRight(subArbolDerecho);
            return current;
        }
    }

    public Citizen getMin(Citizen current){
        if(current.getLeft()==null){
            return current;
        }
        return getMin(current.getRight());
    }

}
