package UI;

import java.util.Scanner;

import Exceptions.NoneExistentCommand;
import Model.Controller;

public class Main {

    static Scanner lector = new Scanner(System.in);

    public static void main(String[] args) {

        Controller controladora = new Controller();
        boolean control = true;
        while (control) {
            int option = menu();
            switch (option) {
                case 1:
                    String ans;
                    System.out.println("Write de command");
                    ans = lector.nextLine();

                    String[] splitedComand = ans.split(" ");

                    // PRINT COMMAND
                    for (String mostrar : splitedComand) {
                        System.out.println(mostrar);
                    }
                    if (splitedComand.length < 2) {
                        System.out.println("Command wrong written");
                        break;
                    }

                    if (splitedComand[0].equals("INSERT") && splitedComand[1].equals("INTO")) {
                        controladora.insert(ans);
                        break;
                    } else if (splitedComand[0].equals("SELECT") && splitedComand[1].equals("*")
                            && splitedComand[2].equals("FROM")) {
                        boolean flag = false;
                        for (int i = 0; i < splitedComand.length - 1; i++) {
                            if (splitedComand[i].equals("ORDER") && splitedComand[i + 1].equals("BY")) {
                                flag = true;
                                break;
                            }
                        }
                        if (flag) {
                            controladora.orderBy(ans);
                        } else {
                            controladora.searchUndFilter(ans);
                        }
                        break;
                    } else if (splitedComand[0].equals("DELETE") && splitedComand[1].equals("FROM")) {
                        controladora.delete(ans);
                        break;
                    } else {
                        throw new NoneExistentCommand();
                    }
                case 2:

                    break;
                case 3:
                    control = false;
                    break;
                default:
                    System.out.println("ERROR SELEC A VALID OPTION!!!");
                    break;
            }
        }

    }

    public static int menu() {
        System.out.println("Welcome to the geographic information System : \n");
        int optMenu;
        System.out.println("Type an Option for the Menu : \n1. Insert Command \n2. Import data from .SQL file \n3. Exit");
        optMenu = lector.nextInt();
        lector.nextLine();
        return optMenu;
    }

}
