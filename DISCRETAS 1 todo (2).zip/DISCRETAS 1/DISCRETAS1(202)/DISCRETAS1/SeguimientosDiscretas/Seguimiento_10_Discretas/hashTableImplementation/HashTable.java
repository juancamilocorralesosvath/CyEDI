package hashTableImplementation;

public class HashTable<K,V>  implements IHashTable<K,V>{
    private int m;
    private HNode<K,V>[] table;

    //Constructor with the parameter m
    public HashTable(int m) {
        this.m = m;
        table = new HNode[m];
    }

     public HashTable() {
        m = 10;
        table = new HNode[m];
    }

    public int hash(Object key) {
        return (Math.abs(key.hashCode())) % m;
    }

    
    public void put(K key, V value) throws Exception 
    {
        int insertKey = hash(key);
        HNode<K,V> nodeList = table[insertKey];

        if(nodeList == null) {
            table[insertKey] = new HNode<>(key, value);
        } else {
            while (nodeList != null) {
                if(nodeList.getKey().equals(key)) {
                    break;
                }
                nodeList = nodeList.getNext();
            }
            HNode<K,V> finalNode = new HNode<>(key, value);
            table[insertKey].setPrevious(finalNode);
            table[insertKey] = finalNode;
        }
    }

    @Override
    public V search(K key) {
        V value = null;
        int searchKey = hash(key);
        HNode<K,V> searchNode = table[searchKey];
        while (searchNode != null) {
            if(searchNode.getKey().equals(key)){
                value = searchNode.getValue();
            }
            searchNode = searchNode.getNext();
        }
        return value;
    }

    @Override
    public void remove(K key) {
        int deleteKey = hash(key);
        HNode<K,V> deleteNode = table[deleteKey];
        while (deleteNode != null){
            if(deleteNode.getKey().equals(key)){
                HNode<K,V> prev = deleteNode.getPrevious();
                HNode<K,V> next = deleteNode.getNext();
                prev.setNext(next);
                next.setPrevious(prev);
            }
            deleteNode = deleteNode.getNext();
        }
    }
}