package ui;
import hashTableImplementation.HashTable;
import java.util.Scanner;


public class Seguimiento_10 
{

  public static void main(String[] args) 
  {

    HashTable< Integer,String > pacientesHospital = new HashTable(1);
    Scanner lector=new Scanner(System.in);

    // Add keys and values (ID, Name , Diasease , Age)
    try {
    pacientesHospital.put(1110245, "Miguel Lopez");    
    pacientesHospital.put(320382, "Santiago Gonzales");
    pacientesHospital.put(96839204, "Sara Machado");
    pacientesHospital.put(7758201, "Marly Biena");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /* 
  //Metod for register a patient if its not registered
  public static void RegistrarPaciente(Scanner lector , HashMap pacientesHospital)
  {
  System.out.print("Register a patient \nID:");
  Integer regId = lector.nextInt();
  System.out.println("Enter the "+regId+" name:");
  String regName = lector.nextLine();

  pacientesHospital.put(regId,regName);
  }

  //Metod for erasing a patient
  public static void EliminarPaciente(Scanner lector, HashMap pacientesHospital)
  {
    System.out.print("Select patient \nID:");
    Integer regId = lector.nextInt();

    pacientesHospital.remove(regId);
} */

}