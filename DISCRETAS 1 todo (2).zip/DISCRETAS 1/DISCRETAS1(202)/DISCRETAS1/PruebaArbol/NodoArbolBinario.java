public class NodoArbolBinario {
    int valor;
    String dato;
    NodoArbolBinario hijoIzquierdo;
    NodoArbolBinario hijoDerecho;
 
    public NodoArbolBinario( int valor, String dato){
        this.dato=dato;
        this.valor=valor;
        hijoDerecho=null;
        hijoIzquierdo=null;
        }
 
    public void mostrar(){
        System.out.println("Puntaje: "+ valor+ " Nombre: "+ dato);
    }

 
}