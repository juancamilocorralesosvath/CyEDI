public class ArbolBinario {
    NodoArbolBinario raiz;
 
    public ArbolBinario(){
        raiz=null;
    }
 
    public ArbolBinario(int valor, String dato){
        raiz= new NodoArbolBinario(valor, dato);
    }
    public void inserta(int valor, String dato){
        NodoArbolBinario nuevo= new NodoArbolBinario(valor, dato);
        if(raiz == null){
            raiz = nuevo; //apunta al nuevo nodo
        }
        else{
            NodoArbolBinario padre = elPadreDe(valor);
            if(valor >= padre.valor)
                padre.hijoDerecho=nuevo;
            else
                padre.hijoIzquierdo=nuevo;
 
            }
 
        }
 
    public NodoArbolBinario elPadreDe(int valor){
       // NodoArbolBinario tmp=raiz;
        NodoArbolBinario padre= BuscarElPadre(valor, raiz);
        return padre;
    }
 
    public NodoArbolBinario BuscarElPadre(int valor, NodoArbolBinario tmp){
 
        if (valor >= tmp.valor && tmp.hijoDerecho!=null ){
            tmp= tmp.hijoDerecho;
            BuscarElPadre(valor, tmp);
        }
        if(valor < tmp.valor && tmp.hijoIzquierdo!=null ){
            tmp=tmp.hijoIzquierdo;
        BuscarElPadre(valor, tmp);
        }
        if (valor >= tmp.valor && tmp.hijoDerecho == null){
            return tmp;
        }
        if (valor < tmp.valor && tmp. hijoIzquierdo == null){
            return tmp;
        }
        return null;
    }
 
    public void mostrar(){
        mostrar(raiz);
    }
 
    public void mostrar(NodoArbolBinario tmp){
        tmp.mostrar();
        if(tmp.hijoIzquierdo!=null)
            mostrar(tmp.hijoIzquierdo);
        if(tmp.hijoDerecho!=null)
            mostrar(tmp.hijoDerecho);
    }
 
    public void mostrarPreOrden(){
        mostrarPreOrden(raiz);
    }
 
    public void mostrarPreOrden(NodoArbolBinario tmp){
        tmp.mostrar();
        if(tmp.hijoIzquierdo!=null)
            mostrarPreOrden(tmp.hijoIzquierdo);
        if(tmp.hijoDerecho!=null)
            mostrarPreOrden(tmp.hijoDerecho);
 
}
    public void mostrarInOrden(){
        mostrarInOrden(raiz);
    }
    public void mostrarInOrden(NodoArbolBinario tmp){
 
        if(tmp.hijoIzquierdo!=null)
            mostrarInOrden(tmp.hijoIzquierdo);
        tmp.mostrar();
        if(tmp.hijoDerecho!=null)
            mostrarInOrden(tmp.hijoDerecho);
 
}
    public void mostrarPostOrden(){
        mostrarInOrden(raiz);
    }
    public void mostrarPostOrden(NodoArbolBinario tmp){
 
        if(tmp.hijoIzquierdo!=null)
            mostrarPostOrden(tmp.hijoIzquierdo);
        tmp.mostrar();
        if(tmp.hijoDerecho!=null)
            mostrarPostOrden(tmp.hijoDerecho);
 
}
 
public void imprimirSegunBuscar(NodoArbolBinario tmp, int nivel,int buscar){
    if(tmp !=null){
                System.out.println(tmp.valor + "("+buscar+") - ");
    }
}


}