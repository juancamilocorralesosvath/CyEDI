import java.util.Scanner;
public class Main {
public static void main(String[] args) {
 
        ArbolBinario a = new ArbolBinario();
        int menu=0;
        int puntaje=0;
        final Scanner lector = new Scanner(System.in);

        while (menu!=5){
            System.out.println("\nBienvenido a EA : \n1. Agregar registro\n2. Buscar registro por puntaje\n3. Ver puntajes de menor a mayor\n4. Ver TOP 10, de mayor a menor\n5. Salir");
            menu=lector.nextInt();
     
            switch (menu){
                case 1:
                System.out.println("Escribe el nombre del jugador: ");
                String nombre=lector.nextLine();
                nombre=lector.nextLine();

                System.out.println("Escribe el puntaje del jugador: ");
                puntaje=lector.nextInt();
                a.inserta(puntaje, nombre);
                break;
    
                case 2:
                System.out.println("Escribe el puntaje a buscar: ");
                int buscar=lector.nextInt();
                System.out.println("Existe en el arbol? ");
                a.imprimirSegunBuscar(null, puntaje, puntaje);
                break;
    
                case 3:
                System.out.println("Puntajes de mayor a menor: ");
                a.mostrar();
                break;
    
                case 4:
                System.out.println("Top 10 Records:");
                
                break;
            }
            
    }
 
    }
 
}
