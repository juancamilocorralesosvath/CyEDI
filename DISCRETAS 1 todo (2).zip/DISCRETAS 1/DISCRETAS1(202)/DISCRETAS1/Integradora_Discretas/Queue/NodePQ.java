package Queue;

public class NodePQ<T> {

    int priorityValue;
    T value;

    public NodePQ(T value, int priorityValue) {
        this.priorityValue = priorityValue;
        this.value = value;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public int getPriorityValue() {
        return priorityValue;
    }

    public void setPriorityValue(int priorityValue) {
        this.priorityValue = priorityValue;
    }

}
