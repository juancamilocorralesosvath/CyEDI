package ui;

import Stack.Stack;
import Queue.HeapMax;
import hashTableImplementation.HashTable;


import java.util.Scanner;
import java.time.*;

public class Main {  
    public static void main(String[] args) throws Exception {

    HeapMax<String> persona = new HeapMax<>();
    Stack<Integer> colaPrioridad = new Stack<>();
    HashTable< Integer,String > pacientesHospital = new HashTable(1);


    int salida=1;

    while (salida!=0){
        Scanner lector= new Scanner(System.in);
        System.out.println("Welcome to EPS \n¿What would you like to do? \n1) Search for a Client \n2) Delete a client \n0)Exit");
        int menu = lector.nextInt();
    
        switch(menu)
        {
            case 1:
            int prioridad=0;
            System.out.println("Type the patient id :");
            int idBuscar=lector.nextInt();
            
            Boolean encontrado = false;
            

            colaPrioridad.push(prioridad);
  

            if(encontrado!=false)
            {
            System.out.print("El paciente si  esta registrado , Aqui sus datos :");
            }else
            {

            System.out.println("NO ENCONTRADO , PORFAVOR REGISTRESE \nRegister a pacient : \nType the patient name :");
            String name=lector.nextLine();
            name=lector.nextLine();
            
            //ID RANDOM
            Integer numero = (int)(Math.random()*999999+10000);
            System.out.println("Here is the patient id :"+numero);
            
            //INSERTAR PERSONA EN EL HASH MAP
            pacientesHospital.put(numero, name);
             
            
            }
            break;
    
            case 2:
            System.out.println("Type the patient id :");
            idBuscar=lector.nextInt();
            pacientesHospital.remove(idBuscar);
            break;
    
            case 0:
            System.out.println("BYE!!!!");
            salida=0;
            break;
        }

        /* 
        //INSERTAR GENTE AL HOSPITAL TEST 
        test.insert(65838, "Santiago Corrales");
        test.insert(20291, "Sara Machado");
        test.insert(39182, "Luis Gonzales");
        test.insert(42049, "Eduardo Figueroa");
        */

        //SACAR EL VALOR MAXIMO DE LA COLA 
        //test.extractMax();

        //IMPRIMIR TODA LA PRIORITY QUEUE
        /* 
        System.out.println(persona.printPQ());



        System.out.println(colaPrioridad.isEmpty());
        System.out.println(colaPrioridad.top());
        //colaPrioridad.pop();
        System.out.println(colaPrioridad.top());
        */
    }
    }

    public static int determinarPrioridad(Scanner lector , int prioridad)
    {
    //SE DETERMINARA UN TIPO DE PRIORIDAD YA SEA PRORITATIA O ACCESO GENERAL
    System.out.println("Ingresa tu edad: ");
    int edad = lector.nextInt();
    
    if(edad<=65)
    {
    prioridad=prioridad+1;
    }

    System.out.println("¿Tienes embarazo o algun tipo de discapacidad?: ");
    int embarazo = lector.nextInt();
    
    if (embarazo==1)
    {
    prioridad=prioridad+1;
    }

    return prioridad;
    }

    public static void eliminarCola(LocalDateTime time,Stack colaPrioridad){
        int minute = time.getMinute(); 
    if (minute%2==0)
    {
        if (colaPrioridad.isEmpty()==false){
        colaPrioridad.pop();   
        }else System.out.println("La cola de prioridad esta vacia!!!");
    
    } 
    }

}
