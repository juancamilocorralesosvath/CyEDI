package hashTableImplementation;

public interface IHashTable<K,V> {
    public void put(K key, V value) throws Exception;
    public V search(K key);
    public void remove(K key);

}