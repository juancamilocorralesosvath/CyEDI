package proyectocolasprio;

public class Pacientes {
    String Cedula;
    String Nombre;
    int Edad;
    int Enfermedad;
    
    int Prioridad;
    public String Sexo;
    public boolean Embarazada;
    public Pacientes(String Cedula, String Nombre, int Edad, int Enfermedad, String Nivel,int p) {
        this.Cedula = Cedula;
        this.Nombre = Nombre;
        this.Edad = Edad;
        this.Enfermedad = Enfermedad;
        this.Prioridad=p;
    }
        public Pacientes(){
            
        }
}
