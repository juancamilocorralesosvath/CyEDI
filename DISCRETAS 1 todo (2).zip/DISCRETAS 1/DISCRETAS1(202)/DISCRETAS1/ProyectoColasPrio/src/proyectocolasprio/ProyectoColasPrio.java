package proyectocolasprio;
import java.util.Scanner;

public class ProyectoColasPrio {

    public static void main(String[] args) 
    {
     Scanner lector=new Scanner(System.in);
     int Tam=100;
     System.out.println("La capacidad de personas es de : "+Tam);
     
     
     Cola Hematologia=new Cola(Tam);
     Cola ColaGeneral=new Cola(Tam);
     int opcion;
     int i=0;

     do
     {
         opcion=menu();
         switch(opcion){
             case 1:
                System.out.println("En que laboratorio deseas registrarte \n1.Laboratorio Hemotologia  \n2.Laboratorio General");
                int laboratorio=lector.nextInt();
                if (laboratorio==1){
                 Hematologia.insertar(RegistroP(i)); 
                 i++;  
                } else
                ColaGeneral.insertar(RegistroP(i));
                i++;
                      break;
             case 2:
                 System.out.println("A cual laboratorio deseas eliminar una persona \n1.Laboratorio Hemotologia  \n2.Laboratorio General");
                 laboratorio=lector.nextInt();
                  if (laboratorio==1){
                  Hematologia.eliminar();
                  }else ColaGeneral.eliminar();
                  
                      break;
             case 3:  
                 System.out.println("¿Cual cola deseas imprimir? \n1.Laboratorio Hemotologia  \n2.Laboratorio General");
                 laboratorio=lector.nextInt();

                 if (laboratorio==1)
                 {
                 Hematologia.imprimir(); 
                 }else ColaGeneral.imprimir();
                     break;

             case 4:  
             System.out.println("Hasta Luego !! , Gracias!");
                      break;
             default:
             System.out.println("ERROR ESA NO ES UNA OPCION !!!!!");
                      break;
         }
     }while(opcion!=4);
        

    }
    public static int menu(){
        Scanner lector = new Scanner(System.in);
        System.out.println("Welcome to the EPS \nMenu:");
        System.out.println("1. Insertar una persona en la cola.");
        System.out.println("2. Eliminar una persona en la cola.");
        System.out.println("3. Imprimir la cola de personas.");
        System.out.println("4. Salir");
        System.out.println("Ingresa la opción:");
        int opcion=lector.nextInt();
        return opcion;
    }
    
    public static Pacientes RegistroP(int i)
    {
            Scanner lector=new Scanner(System.in);
            Pacientes p=new Pacientes();
            int aux = 0;
            int auxx=0;
            System.out.println("El paciente " + (i+1) + " es : \n1.Mujer  \n2.Hombre  :");
            aux = lector.nextInt();
            if (aux == 1){
                p.Sexo = "Mujer";
                System.out.println("¿Esta embarazada la paciente?\n1. Si \n2. No  :");
                auxx = lector.nextInt();
                if (auxx == 1){
                    p.Embarazada = true;
                }
                else p.Embarazada = false;
                
            }
            else if (aux == 2){
                p.Sexo = "Hombre";
            }
            else {
            System.out.println("Valor no aceptado, favor de verificar datos");
             System.out.println("El paciente " + (i+1) + " es : \n1.Mujer  \n2. Hombre  :");
            }
            System.out.println("Paciente número "+ (i+1) +". Cedula:");
            p.Cedula=lector.next();
            System.out.println("Paciente número "+ (i+1) +". Nombre:");
            p.Nombre=lector.next();
            System.out.println("Paciente número "+ (i+1) +". Edad:");
            p.Edad=lector.nextInt();
            

            System.out.println("¿Paciente número "+ (i+1) +". presenta alguna enfermedad de urgencia? \n1. Si \n2. No:");
            p.Enfermedad=lector.nextInt();

            if (p.Edad >= 65 && p.Embarazada == true && p.Enfermedad == 1) 
            {
                p.Prioridad = 6;
                System.out.println("El paciente "+(i)+" esta en la cola de Hematologia.");
            }           
             else if (p.Edad >= 65 && p.Embarazada == true && p.Enfermedad == 2)
            {
                p.Prioridad = 5;
                System.out.println("El paciente "+(i)+" esta en la cola de Hematologia.");
            }
            else if (p.Edad >= 65 && p.Enfermedad==1 )
            {
                p.Prioridad= 4;
                System.out.println("El paciente "+(i)+" esta en la cola de Hematologia.");
            }
            else if (p.Edad >= 65 && p.Enfermedad ==2)
            {
                p.Prioridad= 3;
                System.out.println("El paciente "+(i)+" esta en la cola de Hematologia.");
            }
            else if (p.Embarazada == true )
            {
                p.Prioridad= 2;
                System.out.println("El paciente "+(i)+" esta en la cola de Hematologia.");
            }
            else if (p.Embarazada == true && p.Enfermedad==1)
            {
                p.Prioridad= 3;
                System.out.println("El paciente "+(i)+" esta en la cola de Hematologia.");
            }
            else if ( p.Embarazada== false && p.Enfermedad==2)
            {
                p.Prioridad= 1;
                System.out.println("El paciente "+(i)+" esta en la cola de Hematologia.");
            }
            return p;

    } 

    
/* 
public void egresoAutomatico()
{
        LocalTime time = LocalTime.now();  
        
        int Minute = time.getMinute(); 

        if (Minute % 2== 0){
         Hematologia.eliminar();
         ColaGeneral.eliminar();
        } 
}
*/
}
