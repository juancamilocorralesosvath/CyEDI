public class NodoDoble {
 
    private String dato;
    NodoDoble Siguiente,Anterior;
 
 
    public NodoDoble(String el){
        this(el,null,null);
    }
//Constructor    
    public NodoDoble (String el, NodoDoble s, NodoDoble a){
        dato = el ;
        Siguiente = s;
        Anterior = a;
    }
    public String getDato()
    {
    return dato;
    }
 }
 
 