public class ListaDoblementeEnlazada {
    private NodoDoble inicio,fin;
  
    public ListaDoblementeEnlazada(){
          inicio=fin=null;
 }
  public boolean estVacia(){
      return inicio ==null;
  }
  public void agregarFinal(String el){
      if(!estVacia()){
          fin=new NodoDoble(el,null, fin);
          fin.Anterior.Siguiente=fin;
      }else{
          inicio=fin=new NodoDoble(el);
      }
  }

  public void agregarInicio (String el){
      if(!estVacia()){
          inicio=new NodoDoble(el, inicio, null);
          fin.Siguiente.Anterior=inicio;
      }else{
          inicio=fin=new NodoDoble(el);
      }
  }

  public void mostrarListaInicioFin(){
      if(!estVacia()){
           String datos="=>";
           NodoDoble auxiliar=inicio;
           while (auxiliar!=null){
           datos = datos +"["+auxiliar.getDato()+"]";
           
           auxiliar=auxiliar.Siguiente;
           }
           System.out.println("Aqui la lista de turnos: "+datos);
                }
 }
  public void mostrarListaFinInicio(){
      if(!estVacia()){
           String datos="<=>";
           NodoDoble auxiliar=fin;
           while (auxiliar!=null){
      datos = datos +"["+auxiliar.getDato()+"]<=>";
      auxiliar=auxiliar.Anterior;
           }
          System.out.println("Mostrando datos de FIn a Inicio");
      }
  }
}
