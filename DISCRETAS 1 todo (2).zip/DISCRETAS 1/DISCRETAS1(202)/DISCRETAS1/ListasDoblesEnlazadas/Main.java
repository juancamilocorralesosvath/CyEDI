import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
 
        Scanner sc = new Scanner (System.in);
 
        ListaDoblementeEnlazada Milista=new ListaDoblementeEnlazada();
        int opcion = 0;
        int salir = 0;
        int turnoconta=0;
        String el = "";
        do{
            try{
                     System.out.println(
                                "1.Agregar un Turno al Final\n"
                                + "2.Mostrar Lista de turnos\n"
                                + "3.Mostrar turno actual\n"
                                + "4.Pasar el turno actual\n"
                                + "5.Eliminar un turno actual\n"
                                + "6. Salir\n"
                                + "Elija una opcion:\n ");
                     opcion=sc.nextInt();
            switch (opcion){
                case 1:
                salir=3;
                while (salir!=2){
                    System.out.println(" Agregando Turno al final.... ");
                    turnoconta=turnoconta+1;
                    String numeroCadena=turnoconta+"";
                    el=numeroCadena;
                    Milista.agregarFinal(el);
                    System.out.println("¿Desea agregar otro turno? \n1.SI \n2.NO ");
                    salir=sc.nextInt();
                }
                    break;
 
                case 2:
                if(!Milista.estVacia()){
                        Milista.mostrarListaInicioFin();
                    }else{
                        System.out.println("Lista vacia, no hay Turnos aun");
                    }
                    break;  
 
                case 3:

                break;
                case 4:
                    if(!Milista.estVacia()){
                        Milista.mostrarListaFinInicio();
                    }else{
                        System.out.println("No hay Nodos aun, Lista vacia");
                    }
                    break;
 
                case 5:
                    System.out.println("Aplicacion Finalizada");
                    break;
                default:
                    System.out.println("La opcion no esta en el menu");
                    break;
            }
 
 
            }catch(NumberFormatException n){
                System.out.println("Error");
            }
        }while(opcion!=6);
 
    }
 
}