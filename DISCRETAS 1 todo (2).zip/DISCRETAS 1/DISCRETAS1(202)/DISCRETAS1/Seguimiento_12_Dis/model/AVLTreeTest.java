package model;

import org.junit.Test;

public class AVLTreeTest {
    @Test
    public void testDelete() {

    }

    @Test
    public void testInsert() {

    }
}
