package model;


public class Node<T extends Comparable<T>> {

    private T data;
    private int height = 1;
    private Node<T> leftChild;
    private Node<T> rightChild;

    public Node(){
        
    }

    public Node(T data, int height, Node<T> leftChild, Node<T> rightChild) {
        this.data = data;
        this.height = height;
        this.leftChild = leftChild;
        this.rightChild = rightChild;
    }

    public T getData() {
        return data;
    }
    public void setData(T data) {
        this.data = data;
    }
    public int getHeight() {
        return height;
    }
    public void setHeight(int height) {
        this.height = height;
    }
    public Node<T> getLeftChild() {
        return leftChild;
    }
    public void setLeftChild(Node<T> leftChild) {
        this.leftChild = leftChild;
    }
    public Node<T> getRightChild() {
        return rightChild;
    }
    public void setRightChild(Node<T> rightChild) {
        this.rightChild = rightChild;
    }
    @Override
    public String toString() {
        return "Node [data=" + data + ", height=" + height + ", leftChild=" + leftChild + ", rightChild=" + rightChild
                + "]";
    }

}
