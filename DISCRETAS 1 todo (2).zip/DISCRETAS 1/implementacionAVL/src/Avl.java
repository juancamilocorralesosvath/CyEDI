import java.util.LinkedList;

public class Avl {
    private class Node {
        int key;
        int height;
        Node left;
        Node right;

        Node(int key) {
            this.key = key;
            this.height = 1;
        }
    }

    private Node root;

    // Insertar un nodo en el árbol
    public void insert(int key) {
        root = insertNode(root, key);
    }

    // Función auxiliar para insertar un nodo en el árbol
    private Node insertNode(Node node, int key) {
        // Insertar el nodo como en un árbol binario de búsqueda
        if (node == null) {
            return new Node(key);
        }

        if (key < node.key) {
            node.left = insertNode(node.left, key);
        } else if (key > node.key) {
            node.right = insertNode(node.right, key);
        } else {
            // Si la clave ya existe, no se hace nada
            return node;
        }

        // Actualizar la altura del nodo
        node.height = 1 + Math.max(height(node.left), height(node.right));

        // Rebalancear el árbol si es necesario
        return rebalance(node, key);
    }

    // Reequilibrar el árbol
    private Node rebalance(Node node, int key) {
        // Calcular el factor de equilibrio del nodo
        int balance = getBalance(node);

        // Caso izquierda-izquierda
        if (balance > 1 && key < node.left.key) {
            return rightRotate(node);
        }

        // Caso derecha-derecha
        if (balance < -1 && key > node.right.key) {
            return leftRotate(node);
        }

        // Caso izquierda-derecha
        if (balance > 1 && key > node.left.key) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        // Caso derecha-izquierda
        if (balance < -1 && key < node.right.key) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        // El árbol ya está equilibrado
        return node;
    }

    // Eliminar un nodo del árbol
    public void delete(int key) {
        root = deleteNode(root, key);
    }

    // Función auxiliar para eliminar un nodo del árbol
    private Node deleteNode(Node node, int key) {
        // Eliminar el nodo como en un árbol binario de búsqueda
        if (node == null) {
            return node;
        }

        if (key < node.key) {
            node.left = deleteNode(node.left, key);
        } else if (key > node.key) {
            node.right = deleteNode(node.right, key);
        } else {
            // El nodo es encontrado

            // Si el nodo tiene uno o ningún hijo, se elimina el nodo
            if ((node.left == null) || (node.right == null)) {
                Node temp = null;
                if (temp == node.left) {
                    temp = node.right;
                } else {
                    temp = node.left;
                }

                // Si el nodo no tiene hijos, se elimina simplemente
                if (temp == null) {
                    temp = node;
                    node = null;
                } else { // Si el nodo tiene un hijo, se copia el contenido del hijo al nodo y se elimina el hijo
                    node = temp;
                }
            } else { // El nodo tiene dos hijos, se encuentra el sucesor inorden (menor nodo en el subárbol derecho)
                Node temp = minValueNode(node.right);

                // Se copia el contenido del sucesor al nodo
                node.key = temp.key;

                // Se elimina el sucesor
                node.right = deleteNode(node.right, temp.key);
            }
        }

        // Si el árbol tiene solo un nodo, se devuelve el nodo
        if (node == null) {
            return node;
        }

        // Actualizar la altura del nodo
        node.height = 1 + Math.max(height(node.left), height(node.right));

        // Reequilibrar el árbol si es necesario
        return rebalance(node, key);
    }

    // Realizar una rotación hacia la derecha en un subárbol
    private Node rightRotate(Node node) {
        Node left = node.left;
        Node right = left.right;

        // Realizar la rotación
        left.right = node;
        node.left = right;

        // Actualizar las alturas de los nodos
        node.height = 1 + Math.max(height(node.left), height(node.right));
        left.height = 1 + Math.max(height(left.left), height(left.right));

        return left;
    }

    // Realizar una rotación hacia la izquierda en un subárbol
    private Node leftRotate(Node node) {
        Node right = node.right;
        Node left = right.left;

        // Realizar la rotación
        right.left = node;
        node.right = left;

        // Actualizar las alturas de los nodos
        node.height = 1 + Math.max(height(node.left), height(node.right));
        right.height = 1 + Math.max(height(right.left), height(right.right));

        return right;
    }

    // Obtener la altura de un nodo
    private int height(Node node) {
        if (node == null) {
            return 0;
        }

        return node.height;
    }

    // Obtener el factor de equilibrio de un nodo
    private int getBalance(Node node) {
        if (node == null) {
            return 0;
        }

        return height(node.left) - height(node.right);
    }

    // Obtener el nodo con el valor mínimo en un subárbol
    private Node minValueNode(Node node) {
        Node current = node;

        while (current.left != null) {
            current = current.left;
        }

        return current;
    }

    // Imprimir el árbol en orden ascendente
    public void inorderTraversal() {
        inorder(root);
    }

    private void inorder(Node node) {
        if (node == null) {
            return;
        }

        inorder(node.left);
        System.out.print(node.key + " "+"/n");
        inorder(node.right);
    }
}